﻿
namespace WINUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.carMakeLabel = new System.Windows.Forms.Label();
            this.carMakeTextBox = new System.Windows.Forms.TextBox();
            this.carYearTextBox = new System.Windows.Forms.TextBox();
            this.carYearLabel = new System.Windows.Forms.Label();
            this.carObjectLabel = new System.Windows.Forms.Label();
            this.submitButton = new System.Windows.Forms.Button();
            this.accelerateButton = new System.Windows.Forms.Button();
            this.brakeButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // carMakeLabel
            // 
            this.carMakeLabel.AutoSize = true;
            this.carMakeLabel.Location = new System.Drawing.Point(39, 32);
            this.carMakeLabel.Name = "carMakeLabel";
            this.carMakeLabel.Size = new System.Drawing.Size(72, 17);
            this.carMakeLabel.TabIndex = 0;
            this.carMakeLabel.Text = "Car Make:";
            // 
            // carMakeTextBox
            // 
            this.carMakeTextBox.Location = new System.Drawing.Point(118, 32);
            this.carMakeTextBox.Name = "carMakeTextBox";
            this.carMakeTextBox.Size = new System.Drawing.Size(100, 22);
            this.carMakeTextBox.TabIndex = 1;
            // 
            // carYearTextBox
            // 
            this.carYearTextBox.Location = new System.Drawing.Point(118, 79);
            this.carYearTextBox.Name = "carYearTextBox";
            this.carYearTextBox.Size = new System.Drawing.Size(100, 22);
            this.carYearTextBox.TabIndex = 2;
            // 
            // carYearLabel
            // 
            this.carYearLabel.AutoSize = true;
            this.carYearLabel.Location = new System.Drawing.Point(39, 82);
            this.carYearLabel.Name = "carYearLabel";
            this.carYearLabel.Size = new System.Drawing.Size(68, 17);
            this.carYearLabel.TabIndex = 3;
            this.carYearLabel.Text = "Car Year:";
            // 
            // carObjectLabel
            // 
            this.carObjectLabel.AccessibleDescription = "";
            this.carObjectLabel.AutoSize = true;
            this.carObjectLabel.Location = new System.Drawing.Point(39, 137);
            this.carObjectLabel.Name = "carObjectLabel";
            this.carObjectLabel.Size = new System.Drawing.Size(0, 17);
            this.carObjectLabel.TabIndex = 4;
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(310, 206);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(149, 23);
            this.submitButton.TabIndex = 5;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // accelerateButton
            // 
            this.accelerateButton.Location = new System.Drawing.Point(159, 254);
            this.accelerateButton.Name = "accelerateButton";
            this.accelerateButton.Size = new System.Drawing.Size(149, 23);
            this.accelerateButton.TabIndex = 6;
            this.accelerateButton.Text = "Accelerate";
            this.accelerateButton.UseVisualStyleBackColor = true;
            this.accelerateButton.Click += new System.EventHandler(this.accelerateButton_Click);
            // 
            // brakeButton
            // 
            this.brakeButton.Location = new System.Drawing.Point(476, 254);
            this.brakeButton.Name = "brakeButton";
            this.brakeButton.Size = new System.Drawing.Size(149, 23);
            this.brakeButton.TabIndex = 7;
            this.brakeButton.Text = "Brake";
            this.brakeButton.UseVisualStyleBackColor = true;
            this.brakeButton.Click += new System.EventHandler(this.brakeButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.brakeButton);
            this.Controls.Add(this.accelerateButton);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.carObjectLabel);
            this.Controls.Add(this.carYearLabel);
            this.Controls.Add(this.carYearTextBox);
            this.Controls.Add(this.carMakeTextBox);
            this.Controls.Add(this.carMakeLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label carMakeLabel;
        private System.Windows.Forms.TextBox carMakeTextBox;
        private System.Windows.Forms.TextBox carYearTextBox;
        private System.Windows.Forms.Label carYearLabel;
        private System.Windows.Forms.Label carObjectLabel;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Button accelerateButton;
        private System.Windows.Forms.Button brakeButton;
    }
}

