﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Car_Class_Library;
/**
* 4/30/2023
* CSC 153
* David McCarthy
* This program creates an car object and adds 5 speed when the acceleration button is hitor subtracts 5 speed when the brake button is hit
*/
namespace WINUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void submitButton_Click(object sender, EventArgs e)
        {
            Car userCar = new Car();
            userCar.Make = carMakeTextBox.Text;
            userCar.Year = int.Parse(carYearTextBox.Text);
            userCar.Speed = Car.speed;

            carObjectLabel.Text = userCar.Year.ToString() + " " + userCar.Make + " " + userCar.Speed.ToString() + " mph";
        }

        private void accelerateButton_Click(object sender, EventArgs e)
        {
            Car.speed = Car_Class_Library.Car.Accelerate();
            Car userCar = new Car();
            userCar.Make = carMakeTextBox.Text;
            userCar.Year = int.Parse(carYearTextBox.Text);
            userCar.Speed = Car.speed;

            carObjectLabel.Text = userCar.Year.ToString() + " " + userCar.Make + " " + userCar.Speed.ToString() + " mph";
        }

        private void brakeButton_Click(object sender, EventArgs e)
        {
            Car.speed = Car_Class_Library.Car.Brake();
            Car userCar = new Car();
            userCar.Make = carMakeTextBox.Text;
            userCar.Year = int.Parse(carYearTextBox.Text);
            userCar.Speed = Car.speed;

            carObjectLabel.Text = userCar.Year.ToString() + " " + userCar.Make + " " + userCar.Speed.ToString() + " mph";
        }
    }
}
