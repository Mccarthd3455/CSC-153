﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Class_Library
{
    public class Car
    {
        public static int speed = 0;
        public string Make { get; set; }
        public int Year { get; set; }
        public int Speed { get; set; }

        public Car()
        {

        }
        public Car(string Make, int Year, int Speed = 0)
        {

        }
        public static int Accelerate()
        {
            Car.speed += 5;
            return Car.speed;
        }
        public static int Brake()
        {
            
            Car.speed -= 5;
            return Car.speed;
        }
    }
}
