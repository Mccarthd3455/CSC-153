﻿
namespace WINUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.totalDaysQuestionLabel = new System.Windows.Forms.Label();
            this.medChargesQuestionLabel = new System.Windows.Forms.Label();
            this.totalDaysAnswerTextBox = new System.Windows.Forms.TextBox();
            this.medChargesAnswerTextBox = new System.Windows.Forms.TextBox();
            this.surgicalChargesQuestionLabel = new System.Windows.Forms.Label();
            this.surgicalChargesAnswerTextBox = new System.Windows.Forms.TextBox();
            this.labFeesQuestionLabel = new System.Windows.Forms.Label();
            this.labFeesAnswerTextBox = new System.Windows.Forms.TextBox();
            this.phyRehabQuestionLabel = new System.Windows.Forms.Label();
            this.phyRehabAnswerTextBox = new System.Windows.Forms.TextBox();
            this.stayChargesLabel = new System.Windows.Forms.Label();
            this.miscChargesLabel = new System.Windows.Forms.Label();
            this.totalChargesLabel = new System.Windows.Forms.Label();
            this.calculateChargesButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // totalDaysQuestionLabel
            // 
            this.totalDaysQuestionLabel.AutoSize = true;
            this.totalDaysQuestionLabel.Location = new System.Drawing.Point(19, 29);
            this.totalDaysQuestionLabel.Name = "totalDaysQuestionLabel";
            this.totalDaysQuestionLabel.Size = new System.Drawing.Size(231, 13);
            this.totalDaysQuestionLabel.TabIndex = 0;
            this.totalDaysQuestionLabel.Text = "How many days did you spend at the Hospital? ";
            // 
            // medChargesQuestionLabel
            // 
            this.medChargesQuestionLabel.AutoSize = true;
            this.medChargesQuestionLabel.Location = new System.Drawing.Point(19, 71);
            this.medChargesQuestionLabel.Name = "medChargesQuestionLabel";
            this.medChargesQuestionLabel.Size = new System.Drawing.Size(203, 13);
            this.medChargesQuestionLabel.TabIndex = 1;
            this.medChargesQuestionLabel.Text = "How much were the medication charges?";
            // 
            // totalDaysAnswerTextBox
            // 
            this.totalDaysAnswerTextBox.Location = new System.Drawing.Point(261, 29);
            this.totalDaysAnswerTextBox.Name = "totalDaysAnswerTextBox";
            this.totalDaysAnswerTextBox.Size = new System.Drawing.Size(100, 20);
            this.totalDaysAnswerTextBox.TabIndex = 2;
            // 
            // medChargesAnswerTextBox
            // 
            this.medChargesAnswerTextBox.Location = new System.Drawing.Point(262, 64);
            this.medChargesAnswerTextBox.Name = "medChargesAnswerTextBox";
            this.medChargesAnswerTextBox.Size = new System.Drawing.Size(100, 20);
            this.medChargesAnswerTextBox.TabIndex = 3;
            // 
            // surgicalChargesQuestionLabel
            // 
            this.surgicalChargesQuestionLabel.AutoSize = true;
            this.surgicalChargesQuestionLabel.Location = new System.Drawing.Point(19, 105);
            this.surgicalChargesQuestionLabel.Name = "surgicalChargesQuestionLabel";
            this.surgicalChargesQuestionLabel.Size = new System.Drawing.Size(188, 13);
            this.surgicalChargesQuestionLabel.TabIndex = 4;
            this.surgicalChargesQuestionLabel.Text = "How much were the surgical charges?";
            // 
            // surgicalChargesAnswerTextBox
            // 
            this.surgicalChargesAnswerTextBox.Location = new System.Drawing.Point(262, 102);
            this.surgicalChargesAnswerTextBox.Name = "surgicalChargesAnswerTextBox";
            this.surgicalChargesAnswerTextBox.Size = new System.Drawing.Size(100, 20);
            this.surgicalChargesAnswerTextBox.TabIndex = 5;
            // 
            // labFeesQuestionLabel
            // 
            this.labFeesQuestionLabel.AutoSize = true;
            this.labFeesQuestionLabel.Location = new System.Drawing.Point(19, 145);
            this.labFeesQuestionLabel.Name = "labFeesQuestionLabel";
            this.labFeesQuestionLabel.Size = new System.Drawing.Size(183, 13);
            this.labFeesQuestionLabel.TabIndex = 6;
            this.labFeesQuestionLabel.Text = "How much were the laboratory fees? ";
            // 
            // labFeesAnswerTextBox
            // 
            this.labFeesAnswerTextBox.Location = new System.Drawing.Point(262, 142);
            this.labFeesAnswerTextBox.Name = "labFeesAnswerTextBox";
            this.labFeesAnswerTextBox.Size = new System.Drawing.Size(100, 20);
            this.labFeesAnswerTextBox.TabIndex = 7;
            // 
            // phyRehabQuestionLabel
            // 
            this.phyRehabQuestionLabel.AutoSize = true;
            this.phyRehabQuestionLabel.Location = new System.Drawing.Point(19, 192);
            this.phyRehabQuestionLabel.Name = "phyRehabQuestionLabel";
            this.phyRehabQuestionLabel.Size = new System.Drawing.Size(253, 13);
            this.phyRehabQuestionLabel.TabIndex = 8;
            this.phyRehabQuestionLabel.Text = "How much were the Physical Rehabilation charges?";
            // 
            // phyRehabAnswerTextBox
            // 
            this.phyRehabAnswerTextBox.Location = new System.Drawing.Point(292, 189);
            this.phyRehabAnswerTextBox.Name = "phyRehabAnswerTextBox";
            this.phyRehabAnswerTextBox.Size = new System.Drawing.Size(100, 20);
            this.phyRehabAnswerTextBox.TabIndex = 9;
            // 
            // stayChargesLabel
            // 
            this.stayChargesLabel.AutoSize = true;
            this.stayChargesLabel.Location = new System.Drawing.Point(19, 254);
            this.stayChargesLabel.Name = "stayChargesLabel";
            this.stayChargesLabel.Size = new System.Drawing.Size(73, 13);
            this.stayChargesLabel.TabIndex = 10;
            this.stayChargesLabel.Text = "Stay Charges:";
            // 
            // miscChargesLabel
            // 
            this.miscChargesLabel.AutoSize = true;
            this.miscChargesLabel.Location = new System.Drawing.Point(19, 284);
            this.miscChargesLabel.Name = "miscChargesLabel";
            this.miscChargesLabel.Size = new System.Drawing.Size(119, 13);
            this.miscChargesLabel.TabIndex = 11;
            this.miscChargesLabel.Text = "Miscellaneous Charges:";
            // 
            // totalChargesLabel
            // 
            this.totalChargesLabel.AutoSize = true;
            this.totalChargesLabel.Location = new System.Drawing.Point(19, 313);
            this.totalChargesLabel.Name = "totalChargesLabel";
            this.totalChargesLabel.Size = new System.Drawing.Size(79, 13);
            this.totalChargesLabel.TabIndex = 12;
            this.totalChargesLabel.Text = "Total Charges: ";
            // 
            // calculateChargesButton
            // 
            this.calculateChargesButton.Location = new System.Drawing.Point(22, 345);
            this.calculateChargesButton.Name = "calculateChargesButton";
            this.calculateChargesButton.Size = new System.Drawing.Size(118, 23);
            this.calculateChargesButton.TabIndex = 13;
            this.calculateChargesButton.Text = "Calculate Charges";
            this.calculateChargesButton.UseVisualStyleBackColor = true;
            this.calculateChargesButton.Click += new System.EventHandler(this.calculateChargesButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.calculateChargesButton);
            this.Controls.Add(this.totalChargesLabel);
            this.Controls.Add(this.miscChargesLabel);
            this.Controls.Add(this.stayChargesLabel);
            this.Controls.Add(this.phyRehabAnswerTextBox);
            this.Controls.Add(this.phyRehabQuestionLabel);
            this.Controls.Add(this.labFeesAnswerTextBox);
            this.Controls.Add(this.labFeesQuestionLabel);
            this.Controls.Add(this.surgicalChargesAnswerTextBox);
            this.Controls.Add(this.surgicalChargesQuestionLabel);
            this.Controls.Add(this.medChargesAnswerTextBox);
            this.Controls.Add(this.totalDaysAnswerTextBox);
            this.Controls.Add(this.medChargesQuestionLabel);
            this.Controls.Add(this.totalDaysQuestionLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label totalDaysQuestionLabel;
        private System.Windows.Forms.Label medChargesQuestionLabel;
        private System.Windows.Forms.TextBox totalDaysAnswerTextBox;
        private System.Windows.Forms.TextBox medChargesAnswerTextBox;
        private System.Windows.Forms.Label surgicalChargesQuestionLabel;
        private System.Windows.Forms.TextBox surgicalChargesAnswerTextBox;
        private System.Windows.Forms.Label labFeesQuestionLabel;
        private System.Windows.Forms.TextBox labFeesAnswerTextBox;
        private System.Windows.Forms.Label phyRehabQuestionLabel;
        private System.Windows.Forms.TextBox phyRehabAnswerTextBox;
        private System.Windows.Forms.Label stayChargesLabel;
        private System.Windows.Forms.Label miscChargesLabel;
        private System.Windows.Forms.Label totalChargesLabel;
        private System.Windows.Forms.Button calculateChargesButton;
    }
}

