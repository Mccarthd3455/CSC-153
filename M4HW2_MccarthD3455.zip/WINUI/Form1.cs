﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HospitalChargesCalculator;
/**
* 3/22/2023
* CSC 153
* David McCarthy
* This program does hospital charges calculations by asking the user for time spent at the hospital, cost of medication charges, cost of surgical charges, 
* cost of the laboratory fees, and the cost of the physical rehabilation. Then splits the calculations into 3 different methods. Each method responsible for one part
* of the calculation. One method for Stay charges, Miscellaneous charges, and Total Charges. 
*/
namespace WINUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateChargesButton_Click(object sender, EventArgs e)
        {
            const double dailyCharge = 350.00; //variable used in the CalcStayCharges method for calculating stay charge 
            int userTotalDays; //userInput variable used in the CalcMiscCharges method for calculating Miscellaneous charges
            double userMedCharges;//userInput variable used in the CalcMiscCharges method for calculating Miscellaneous charges
            double userSurgicalCharges; //userInput variable used in the CalcMiscCharges method for calculating Miscellaneous charges
            double userLabFees; //userInput variable used in the CalcMiscCharges method for calculating Miscellaneous charges
            double userPhyRehabCharges; //userInput variable used in the CalcMiscCharges method for calculating Miscellaneous charges

            userTotalDays = int.Parse(totalDaysAnswerTextBox.Text); //Takes whatever is in the text box and converts it to a int
            userMedCharges = double.Parse(medChargesAnswerTextBox.Text); // Takes whatever is in the text box and converts it to a double
            userSurgicalCharges = double.Parse(surgicalChargesAnswerTextBox.Text);// Takes whatever is in the text box and converts it to a double
            userLabFees = double.Parse(labFeesAnswerTextBox.Text);// Takes whatever is in the text box and converts it to a double
            userPhyRehabCharges = double.Parse(phyRehabAnswerTextBox.Text);// Takes whatever is in the text box and converts it to a double

            double stayCharges = HospitalCalulations.CalcStayCharges(dailyCharge, userTotalDays); //Calls the CalcStayCharges Method from the HospitalChargesCalculator class library
            double miscCharges = HospitalCalulations.CalcMiscCharges(userMedCharges, userSurgicalCharges, userLabFees, userPhyRehabCharges); //Calls the CalcMiscCharges Method from the HospitalChargesCalculator class library
            double totalCharges = HospitalCalulations.CalcTotalCharges(stayCharges, miscCharges);//Calls the CalcTotalCharges Method from the HospitalChargesCalculator class library

            stayChargesLabel.Text = ("Stay Charges: " + stayCharges.ToString()); // converts the stayCharges variable to a string and displays it on the stayChargesLabel
            miscChargesLabel.Text = ("Miscellaneous Charges: " + miscCharges.ToString());// converts the miscCharges to a string and displays it on the miscChargesLabel
            totalChargesLabel.Text = ("Total Charges: " + totalCharges.ToString());// converts the totalCharges to a string and displays it on the totalChargesLabel
        }
    }
}
