﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalChargesCalculator
{
    public class HospitalCalulations
    {
        public static double CalcStayCharges(double dailyCharge, int userTotalDays)
        {
            double stayCharges; //variable for stay charges 
            stayCharges = dailyCharge * userTotalDays; // calculations for stay charges
            return stayCharges; //returns stayCharges 
        }
        public static double CalcMiscCharges(double userMedCharges, double userSurgicalCharges, double userLabFees, double userPhyRehabCharges)
        {
            double miscCharges; //varivable for miscellaneous charges
            miscCharges = userMedCharges + userSurgicalCharges + userLabFees + userPhyRehabCharges; //calculations for miscellaneous charges
            return miscCharges; //returns miscellaneous charges
        }
        public static double CalcTotalCharges(double stayCharges, double miscCharges)
        {
            double totalCharges; //variable for total charges
            totalCharges = stayCharges + miscCharges; //Calculations for total Charges
            return totalCharges; //returns totalCharges
        }
    }
}
