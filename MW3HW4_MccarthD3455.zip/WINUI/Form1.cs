﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
/**
* 3/10/23
* CSC 153
* David McCarthy
* This program reads a file and adds them to a list 
*/
namespace WINUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void readFileButton_Click(object sender, EventArgs e)
        {
            int randomNumCounter = 0;
            string randomNumber;
            StreamReader inputFile;
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                inputFile = File.OpenText(openFile.FileName);
                while(! inputFile.EndOfStream) //loop to get all of the input from the file
                {
                    randomNumber = inputFile.ReadLine(); //reads the file's line
                    randomNumListBox.Items.Add(randomNumber); //adds the read line to the list
                    randomNumCounter++;  //adds 1 to the counter variable
                }
                randomNumListBox.Items.Add("Total items: " + randomNumCounter); //Puts total items and the counter variable to the list
            }
            else
            {
              MessageBox.Show("Operation canceled.");
            }
        }
    }
}
