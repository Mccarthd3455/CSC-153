﻿
namespace WINUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.slotSymbolsImageList = new System.Windows.Forms.ImageList(this.components);
            this.firstSlotPictureBox = new System.Windows.Forms.PictureBox();
            this.secondSlotPictureBox = new System.Windows.Forms.PictureBox();
            this.thirdSlotPictureBox = new System.Windows.Forms.PictureBox();
            this.userAmountLabel = new System.Windows.Forms.Label();
            this.userInputAmountTextBox = new System.Windows.Forms.TextBox();
            this.spinButton = new System.Windows.Forms.Button();
            this.winningAmountLabel = new System.Windows.Forms.Label();
            this.slotMachineTitleLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.firstSlotPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.secondSlotPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thirdSlotPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // slotSymbolsImageList
            // 
            this.slotSymbolsImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("slotSymbolsImageList.ImageStream")));
            this.slotSymbolsImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.slotSymbolsImageList.Images.SetKeyName(0, "Apple.bmp");
            this.slotSymbolsImageList.Images.SetKeyName(1, "Banana.bmp");
            this.slotSymbolsImageList.Images.SetKeyName(2, "Cherries.bmp");
            this.slotSymbolsImageList.Images.SetKeyName(3, "Grapes.bmp");
            this.slotSymbolsImageList.Images.SetKeyName(4, "Lemon.bmp");
            this.slotSymbolsImageList.Images.SetKeyName(5, "Lime.bmp");
            this.slotSymbolsImageList.Images.SetKeyName(6, "Orange.bmp");
            this.slotSymbolsImageList.Images.SetKeyName(7, "Pear.bmp");
            this.slotSymbolsImageList.Images.SetKeyName(8, "Strawberry.bmp");
            this.slotSymbolsImageList.Images.SetKeyName(9, "Watermelon.bmp");
            // 
            // firstSlotPictureBox
            // 
            this.firstSlotPictureBox.Location = new System.Drawing.Point(127, 76);
            this.firstSlotPictureBox.Name = "firstSlotPictureBox";
            this.firstSlotPictureBox.Size = new System.Drawing.Size(118, 115);
            this.firstSlotPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.firstSlotPictureBox.TabIndex = 0;
            this.firstSlotPictureBox.TabStop = false;
            // 
            // secondSlotPictureBox
            // 
            this.secondSlotPictureBox.Location = new System.Drawing.Point(304, 76);
            this.secondSlotPictureBox.Name = "secondSlotPictureBox";
            this.secondSlotPictureBox.Size = new System.Drawing.Size(118, 115);
            this.secondSlotPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.secondSlotPictureBox.TabIndex = 1;
            this.secondSlotPictureBox.TabStop = false;
            // 
            // thirdSlotPictureBox
            // 
            this.thirdSlotPictureBox.Location = new System.Drawing.Point(479, 76);
            this.thirdSlotPictureBox.Name = "thirdSlotPictureBox";
            this.thirdSlotPictureBox.Size = new System.Drawing.Size(118, 115);
            this.thirdSlotPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.thirdSlotPictureBox.TabIndex = 2;
            this.thirdSlotPictureBox.TabStop = false;
            // 
            // userAmountLabel
            // 
            this.userAmountLabel.AutoSize = true;
            this.userAmountLabel.Location = new System.Drawing.Point(192, 227);
            this.userAmountLabel.Name = "userAmountLabel";
            this.userAmountLabel.Size = new System.Drawing.Size(109, 15);
            this.userAmountLabel.TabIndex = 3;
            this.userAmountLabel.Text = "Amount Inserted: $";
            // 
            // userInputAmountTextBox
            // 
            this.userInputAmountTextBox.Location = new System.Drawing.Point(304, 224);
            this.userInputAmountTextBox.Name = "userInputAmountTextBox";
            this.userInputAmountTextBox.Size = new System.Drawing.Size(100, 20);
            this.userInputAmountTextBox.TabIndex = 4;
            // 
            // spinButton
            // 
            this.spinButton.Location = new System.Drawing.Point(284, 281);
            this.spinButton.Name = "spinButton";
            this.spinButton.Size = new System.Drawing.Size(122, 23);
            this.spinButton.TabIndex = 5;
            this.spinButton.Text = "Spin!";
            this.spinButton.UseVisualStyleBackColor = true;
            this.spinButton.Click += new System.EventHandler(this.spinButton_Click);
            // 
            // winningAmountLabel
            // 
            this.winningAmountLabel.AutoSize = true;
            this.winningAmountLabel.Location = new System.Drawing.Point(192, 257);
            this.winningAmountLabel.Name = "winningAmountLabel";
            this.winningAmountLabel.Size = new System.Drawing.Size(81, 15);
            this.winningAmountLabel.TabIndex = 6;
            this.winningAmountLabel.Text = "Amount won: ";
            // 
            // slotMachineTitleLabel
            // 
            this.slotMachineTitleLabel.AutoSize = true;
            this.slotMachineTitleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.slotMachineTitleLabel.Location = new System.Drawing.Point(195, 13);
            this.slotMachineTitleLabel.Name = "slotMachineTitleLabel";
            this.slotMachineTitleLabel.Size = new System.Drawing.Size(383, 39);
            this.slotMachineTitleLabel.TabIndex = 7;
            this.slotMachineTitleLabel.Text = "Slot Machine Simulation";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.slotMachineTitleLabel);
            this.Controls.Add(this.winningAmountLabel);
            this.Controls.Add(this.spinButton);
            this.Controls.Add(this.userInputAmountTextBox);
            this.Controls.Add(this.userAmountLabel);
            this.Controls.Add(this.thirdSlotPictureBox);
            this.Controls.Add(this.secondSlotPictureBox);
            this.Controls.Add(this.firstSlotPictureBox);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.firstSlotPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.secondSlotPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thirdSlotPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ImageList slotSymbolsImageList;
        private System.Windows.Forms.PictureBox firstSlotPictureBox;
        private System.Windows.Forms.PictureBox secondSlotPictureBox;
        private System.Windows.Forms.PictureBox thirdSlotPictureBox;
        private System.Windows.Forms.Label userAmountLabel;
        private System.Windows.Forms.TextBox userInputAmountTextBox;
        private System.Windows.Forms.Button spinButton;
        private System.Windows.Forms.Label winningAmountLabel;
        private System.Windows.Forms.Label slotMachineTitleLabel;
    }
}

