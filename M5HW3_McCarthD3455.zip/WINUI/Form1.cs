﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 4/19/2023
* CSC 153
* David McCarthy
* This program simulates a slot machine by creating 3 random variables to use as an index for the image list index. If the all indices match then the user will
* win 3 times the amount they've entered. If 2 of the indices match then the user will win 2 times the amount they've entered. If none match they get 0 dollars.
*/
namespace WINUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void spinButton_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            double userCashAmount;
            double userWinningAmount;
            int slotSymbolIndex1; //used as index for imagelist
            int slotSymbolIndex2; //used as index for imagelist
            int slotSymbolIndex3; //used as index for imagelist
            int amountInImageList = slotSymbolsImageList.Images.Count; //Sets the limit for the image list as an int so it can be passed into a method

            userCashAmount = int.Parse(userInputAmountTextBox.Text);

            slotSymbolIndex1 = Slot_Machine_Processing.SlotMachineProcessing.GetRandomIndex1(amountInImageList, rand); //method for index1
            slotSymbolIndex2 = Slot_Machine_Processing.SlotMachineProcessing.GetRandomIndex2(amountInImageList, rand); //method for index2
            slotSymbolIndex3 = Slot_Machine_Processing.SlotMachineProcessing.GetRandomIndex3(amountInImageList, rand); //method for index3

            firstSlotPictureBox.Image = slotSymbolsImageList.Images[slotSymbolIndex1]; //displays the image at the random index
            secondSlotPictureBox.Image = slotSymbolsImageList.Images[slotSymbolIndex2]; //displays the image at the random index
            thirdSlotPictureBox.Image = slotSymbolsImageList.Images[slotSymbolIndex3]; //displays the image at the random index

            userWinningAmount = Slot_Machine_Processing.SlotMachineProcessing.ProcessWinnings(slotSymbolIndex1, slotSymbolIndex2, slotSymbolIndex3, userCashAmount); //method to calculate winnning amount

            winningAmountLabel.Text = Slot_Machine_Processing.SlotMachineProcessing.DisplayWinnings(userWinningAmount); //displays winnings as a string in a label
        }
    }
}
