﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slot_Machine_Processing
{
    public static class SlotMachineProcessing
    {
        public static int GetRandomIndex1(int amountInImageList, Random rand)
        {
            int slotSymbolIndex1;
            slotSymbolIndex1 = rand.Next(amountInImageList); //Gets random number between 0-9
            return slotSymbolIndex1; //returns number
        }

        public static int GetRandomIndex2(int amountInImageList, Random rand)
        {
            int slotSymbolIndex2;
            slotSymbolIndex2 = rand.Next(amountInImageList); //Gets random number between 0-9
            return slotSymbolIndex2; //returns number
        }

        public static int GetRandomIndex3(int amountInImageList, Random rand)
        {
            int slotSymbolIndex3;
            slotSymbolIndex3 = rand.Next(amountInImageList); //Gets random number between 0-9
            return slotSymbolIndex3; //returns number
        }
        public static double ProcessWinnings(int slotSymbolIndex1, int slotSymbolIndex2, int slotSymbolIndex3, double userCashAmount)
        {
            double userWinningAmount;
            if (slotSymbolIndex1 == slotSymbolIndex2 && slotSymbolIndex1 == slotSymbolIndex3) //if all indices match it will do whats in the statement
            {
                userWinningAmount = userCashAmount * 3;
            }
            else if (slotSymbolIndex1 == slotSymbolIndex2 || slotSymbolIndex1 == slotSymbolIndex3 || slotSymbolIndex2 == slotSymbolIndex3) //if 2 indices match it will do whats in the statement
            {
                userWinningAmount = userCashAmount * 2;
            }
            else
            {
                userWinningAmount = 0; //If no indices match it will be 0
            }
            return userWinningAmount; //return the winning amount
        }

        public static string DisplayWinnings(double userWinningAmount)
        {
            string winningAmount; //sets the user winning amount as a string
            winningAmount = "Amount Won: $" + userWinningAmount; 
            return winningAmount; //when returned it inserts the string into the text box
        }
    }
}
