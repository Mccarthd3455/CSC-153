﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 3/2/2023
* CSC 153
* David McCarthy
* Let's user play a random guessing gane and tells them if the guess is higher or lower than the random number 
*/
namespace WINUI
{
    public partial class Form1 : Form
    {
        Random rand = new Random();
        int randomNum;
        int guessAmount = 0;
        public Form1()
        {
            InitializeComponent();
            randomNum = rand.Next(1, 101);
        }

        private void guessButton_Click(object sender, EventArgs e)
        {
            int userInput;
            guessAmount += 1;
            userInput = int.Parse(userInputTextBox.Text);
            if (userInput == randomNum)
            {
                guessAmountHighLowLabel.Text = "You guessed it. Yipee!!! Try Again.";
                guessCounterLabel.Text = guessAmount.ToString();
                randomNum = rand.Next(1, 101);
                userInputTextBox.Text = "";
                guessAmount = 0;
            }
            else if (userInput > randomNum)
            {
                guessAmountHighLowLabel.Text = "Guess (Too High or Too Low): Too High, Try Again.";
                guessCounterLabel.Text = guessAmount.ToString();
                userInput = int.Parse(userInputTextBox.Text);

            }
            else if (userInput < randomNum)
            {
                guessAmountHighLowLabel.Text = "Guess (Too High or Too Low): Too Low, Try Again";
                userInput = int.Parse(userInputTextBox.Text);
                guessCounterLabel.Text = guessAmount.ToString();
            }
        }
    }
}
