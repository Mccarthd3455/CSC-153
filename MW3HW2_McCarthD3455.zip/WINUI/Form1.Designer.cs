﻿
namespace WINUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.userInputLabel = new System.Windows.Forms.Label();
            this.gameDescriptionLabel = new System.Windows.Forms.Label();
            this.guessCounterLabel = new System.Windows.Forms.Label();
            this.guessButton = new System.Windows.Forms.Button();
            this.userInputTextBox = new System.Windows.Forms.TextBox();
            this.guessAmountHighLowLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // userInputLabel
            // 
            this.userInputLabel.AutoSize = true;
            this.userInputLabel.Location = new System.Drawing.Point(30, 23);
            this.userInputLabel.Name = "userInputLabel";
            this.userInputLabel.Size = new System.Drawing.Size(129, 13);
            this.userInputLabel.TabIndex = 0;
            this.userInputLabel.Text = "Enter in a number (1-100):";
            // 
            // gameDescriptionLabel
            // 
            this.gameDescriptionLabel.AutoSize = true;
            this.gameDescriptionLabel.Location = new System.Drawing.Point(397, 23);
            this.gameDescriptionLabel.Name = "gameDescriptionLabel";
            this.gameDescriptionLabel.Size = new System.Drawing.Size(318, 39);
            this.gameDescriptionLabel.TabIndex = 1;
            this.gameDescriptionLabel.Text = "Game Description: \r\nTake attempts at guessing a random number between 1 and 100. " +
    "\r\nEach time you input a guess the guess counter will go up.";
            // 
            // guessCounterLabel
            // 
            this.guessCounterLabel.AutoSize = true;
            this.guessCounterLabel.Location = new System.Drawing.Point(33, 74);
            this.guessCounterLabel.Name = "guessCounterLabel";
            this.guessCounterLabel.Size = new System.Drawing.Size(80, 13);
            this.guessCounterLabel.TabIndex = 2;
            this.guessCounterLabel.Text = "Guess Counter:";
            // 
            // guessButton
            // 
            this.guessButton.Location = new System.Drawing.Point(36, 219);
            this.guessButton.Name = "guessButton";
            this.guessButton.Size = new System.Drawing.Size(123, 23);
            this.guessButton.TabIndex = 3;
            this.guessButton.Text = "Guess";
            this.guessButton.UseVisualStyleBackColor = true;
            this.guessButton.Click += new System.EventHandler(this.guessButton_Click);
            // 
            // userInputTextBox
            // 
            this.userInputTextBox.Location = new System.Drawing.Point(166, 23);
            this.userInputTextBox.Name = "userInputTextBox";
            this.userInputTextBox.Size = new System.Drawing.Size(100, 20);
            this.userInputTextBox.TabIndex = 4;
            // 
            // guessAmountHighLowLabel
            // 
            this.guessAmountHighLowLabel.AutoSize = true;
            this.guessAmountHighLowLabel.Location = new System.Drawing.Point(33, 110);
            this.guessAmountHighLowLabel.Name = "guessAmountHighLowLabel";
            this.guessAmountHighLowLabel.Size = new System.Drawing.Size(150, 13);
            this.guessAmountHighLowLabel.TabIndex = 5;
            this.guessAmountHighLowLabel.Text = "Guess (Too High or Too Low):";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.guessAmountHighLowLabel);
            this.Controls.Add(this.userInputTextBox);
            this.Controls.Add(this.guessButton);
            this.Controls.Add(this.guessCounterLabel);
            this.Controls.Add(this.gameDescriptionLabel);
            this.Controls.Add(this.userInputLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label userInputLabel;
        private System.Windows.Forms.Label gameDescriptionLabel;
        private System.Windows.Forms.Label guessCounterLabel;
        private System.Windows.Forms.Button guessButton;
        private System.Windows.Forms.TextBox userInputTextBox;
        private System.Windows.Forms.Label guessAmountHighLowLabel;
    }
}

