﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime_Number_Calculations
{
    public class Prime_Number_Calculator
    {
        public static bool IsPrime(int userInput) //method used for calculating if the number is Prime or not
        {
            bool IsPrimeNumber = true; //defaults the boolean to true
            int i = 2; //defaults the counter to 2 
            while (i < userInput) //This is a loop that will only work if the userInput is greater than the counter. Meaning that if the user inputs 1 or 2 it uses the default boolean value which is true
            {
                if (userInput % i == 0)//Test the input to see if it is evenly divisible by 2
                {
                    IsPrimeNumber = false; //If the input is evenly divided by 2 or whatever the counter is it sets the boolean to false which means it is not a prime number
                }
                i++; //increments the counter variable
            }

            return IsPrimeNumber; //returns if the value is a prime number or not
        }
    }
    

}
