﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Prime_Number_Calculations;
/**
* 3/29/2023
* CSC 153
* David McCarthy
* Ask user to enter in a number and calculates if it is a prime number or not
*/
namespace WINUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculatePrimeButton_Click(object sender, EventArgs e)
        {
            string userNum;
            int userInput = int.Parse(userInputAnswerTextBox.Text); //Parses whatever is in the text box to an Int so it can be used in the calculations
            bool IsPrimeNumber = Prime_Number_Calculations.Prime_Number_Calculator.IsPrime(userInput); //Calls the method that is in the class library
            userNum = userInputAnswerTextBox.Text; //Uses whatever is in the textbox as the string for userNum

            if (IsPrimeNumber == true) //If the boolean is true then it will display that it is a prime number but if the boolean is false it will display that it is not a prime number
            {
                primeCalculationLabel.Text = (userNum + " is a prime number"); //Displays that the number is a prime number
            }
            else
            {
                primeCalculationLabel.Text = (userNum + " is not a prime number"); //Displays that the number is not a prime number
            }



        }
    }
}
