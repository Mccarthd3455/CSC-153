﻿
namespace WINUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.userInputQuestionLabel = new System.Windows.Forms.Label();
            this.userInputAnswerTextBox = new System.Windows.Forms.TextBox();
            this.calculatePrimeButton = new System.Windows.Forms.Button();
            this.primeCalculationLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // userInputQuestionLabel
            // 
            this.userInputQuestionLabel.AutoSize = true;
            this.userInputQuestionLabel.Location = new System.Drawing.Point(12, 33);
            this.userInputQuestionLabel.Name = "userInputQuestionLabel";
            this.userInputQuestionLabel.Size = new System.Drawing.Size(182, 13);
            this.userInputQuestionLabel.TabIndex = 0;
            this.userInputQuestionLabel.Text = "Enter in a number to test if it is prime: ";
            // 
            // userInputAnswerTextBox
            // 
            this.userInputAnswerTextBox.Location = new System.Drawing.Point(200, 30);
            this.userInputAnswerTextBox.Name = "userInputAnswerTextBox";
            this.userInputAnswerTextBox.Size = new System.Drawing.Size(100, 20);
            this.userInputAnswerTextBox.TabIndex = 1;
            // 
            // calculatePrimeButton
            // 
            this.calculatePrimeButton.Location = new System.Drawing.Point(15, 209);
            this.calculatePrimeButton.Name = "calculatePrimeButton";
            this.calculatePrimeButton.Size = new System.Drawing.Size(179, 23);
            this.calculatePrimeButton.TabIndex = 2;
            this.calculatePrimeButton.Text = "Test Number";
            this.calculatePrimeButton.UseVisualStyleBackColor = true;
            this.calculatePrimeButton.Click += new System.EventHandler(this.calculatePrimeButton_Click);
            // 
            // primeCalculationLabel
            // 
            this.primeCalculationLabel.AutoSize = true;
            this.primeCalculationLabel.Location = new System.Drawing.Point(15, 90);
            this.primeCalculationLabel.Name = "primeCalculationLabel";
            this.primeCalculationLabel.Size = new System.Drawing.Size(0, 13);
            this.primeCalculationLabel.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.primeCalculationLabel);
            this.Controls.Add(this.calculatePrimeButton);
            this.Controls.Add(this.userInputAnswerTextBox);
            this.Controls.Add(this.userInputQuestionLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label userInputQuestionLabel;
        private System.Windows.Forms.TextBox userInputAnswerTextBox;
        private System.Windows.Forms.Button calculatePrimeButton;
        private System.Windows.Forms.Label primeCalculationLabel;
    }
}

