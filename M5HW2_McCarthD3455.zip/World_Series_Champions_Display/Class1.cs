﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace World_Series_Champions_Display
{
    public static class Class1
    {
        public static List<string> DisplayList()
        {
            StreamReader teamsReader;
            List <String> mlbTeamsListBox = new List<string>(); //creates list

            teamsReader = File.OpenText("Teams.txt"); //opens file
            while (!teamsReader.EndOfStream) //a loop for reading the file
            {
                mlbTeamsListBox.Add(teamsReader.ReadLine()); //adds what it read to a list
            }
            teamsReader.Close(); //closes file
            return mlbTeamsListBox; //returns list
        }
        public static int DisplayChampionships(string selectedTeam)
        {
            StreamReader championsReader;
            championsReader = File.OpenText("WorldSeriesChampions.txt"); //opens file
            int championshipCounter = 0; //counter variable

            while (!championsReader.EndOfStream) //loop for reading file
            {
                if (selectedTeam.Equals(championsReader.ReadLine())) //checks to see if what it read is what is selected in the list box
                {
                    championshipCounter++; //increases counter if what it reads is what is selected in the list box
                }
            }
            championsReader.Close(); //closes file
            return championshipCounter; //returns counter variable
        }
    }
}
