﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
/**
* 4/16/2023
* CSC 153
* David McCarthy
* Reads a file with all of the mlb teams then adds it to a listbox after that it checks what the user has selected and then reads another file 
* with all of the winners of the World Series on it and counts how many times the selected team has won a world series
*/
namespace WINUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayTeamsButton_Click(object sender, EventArgs e)
        {
            List<string> mlbTeamList = new List<string>(); //Creates a list
            mlbTeamList = World_Series_Champions_Display.Class1.DisplayList(); //Calls display method
            for (int i = 0; i < mlbTeamList.Count; i++) //loop to add items from method to listbox
            {
                mlbTeamsListBox.Items.Add(mlbTeamList.ElementAt(i));
            }
            mlbTeamsListBox.SetSelected(0, true); //sets listbox selected as the first one as default

        }

        private void championshipCheckerButton_Click(object sender, EventArgs e)
        {
            string selectedTeam;
            int championshipAmount;
            selectedTeam = mlbTeamsListBox.GetItemText(mlbTeamsListBox.SelectedItem); //Gets the items name and sets it as a variable to use in method
            championshipAmount = World_Series_Champions_Display.Class1.DisplayChampionships(selectedTeam); //calls method
            amountOfWorldSeriesWins.Text = ("The amount of World Series wins for the " + selectedTeam + ": " + championshipAmount); //displays output
        }
    }
}
