﻿
namespace WINUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mlbTeamsListBox = new System.Windows.Forms.ListBox();
            this.amountOfWorldSeriesWins = new System.Windows.Forms.Label();
            this.displayTeamsButton = new System.Windows.Forms.Button();
            this.championshipCheckerButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // mlbTeamsListBox
            // 
            this.mlbTeamsListBox.FormattingEnabled = true;
            this.mlbTeamsListBox.ItemHeight = 16;
            this.mlbTeamsListBox.Location = new System.Drawing.Point(12, 21);
            this.mlbTeamsListBox.Name = "mlbTeamsListBox";
            this.mlbTeamsListBox.Size = new System.Drawing.Size(240, 84);
            this.mlbTeamsListBox.TabIndex = 0;
            // 
            // amountOfWorldSeriesWins
            // 
            this.amountOfWorldSeriesWins.AutoSize = true;
            this.amountOfWorldSeriesWins.Location = new System.Drawing.Point(9, 142);
            this.amountOfWorldSeriesWins.Name = "amountOfWorldSeriesWins";
            this.amountOfWorldSeriesWins.Size = new System.Drawing.Size(357, 17);
            this.amountOfWorldSeriesWins.TabIndex = 1;
            this.amountOfWorldSeriesWins.Text = "The amount of World Series wins for the selected team:";
            // 
            // displayTeamsButton
            // 
            this.displayTeamsButton.Location = new System.Drawing.Point(13, 194);
            this.displayTeamsButton.Name = "displayTeamsButton";
            this.displayTeamsButton.Size = new System.Drawing.Size(119, 23);
            this.displayTeamsButton.TabIndex = 2;
            this.displayTeamsButton.Text = "Display Teams";
            this.displayTeamsButton.UseVisualStyleBackColor = true;
            this.displayTeamsButton.Click += new System.EventHandler(this.displayTeamsButton_Click);
            // 
            // championshipCheckerButton
            // 
            this.championshipCheckerButton.Location = new System.Drawing.Point(198, 193);
            this.championshipCheckerButton.Name = "championshipCheckerButton";
            this.championshipCheckerButton.Size = new System.Drawing.Size(185, 23);
            this.championshipCheckerButton.TabIndex = 3;
            this.championshipCheckerButton.Text = "Check Championships";
            this.championshipCheckerButton.UseVisualStyleBackColor = true;
            this.championshipCheckerButton.Click += new System.EventHandler(this.championshipCheckerButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.championshipCheckerButton);
            this.Controls.Add(this.displayTeamsButton);
            this.Controls.Add(this.amountOfWorldSeriesWins);
            this.Controls.Add(this.mlbTeamsListBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox mlbTeamsListBox;
        private System.Windows.Forms.Label amountOfWorldSeriesWins;
        private System.Windows.Forms.Button displayTeamsButton;
        private System.Windows.Forms.Button championshipCheckerButton;
    }
}

