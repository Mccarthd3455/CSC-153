﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 3/9/2023
* CSC 153
* David McCarthy
* It ask the user how many days they've worked and it calculates their pay for the amount of days they've worked
* and adds previous days pay to the total
*/
namespace WINUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculatePayButton_Click(object sender, EventArgs e)
        {
            int amountOfDays = 0;
            double totalPay = 0;
            int i;
            double currentPay = 0;

            amountOfDays = int.Parse(amountOfDaysTextBox.Text); //Converts the users input to Integer

            for (i = 1; i <= amountOfDays; i++)
            {
                currentPay = Math.Pow(2, (i-1)); //Creates the math forumla 2^(i - 1) i is the counter for the loop
                totalPay += currentPay; //Adds previous pay to the total pay
            }
            totalPay = totalPay * 0.01; // Makes the pay into pennies
            totalPayLabel.Text = totalPay.ToString(); // Displays user's total pay

        }
    }
}
