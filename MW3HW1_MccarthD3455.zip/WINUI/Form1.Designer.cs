﻿
namespace WINUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.amountOfDaysLabel = new System.Windows.Forms.Label();
            this.amountOfDaysTextBox = new System.Windows.Forms.TextBox();
            this.calculatePayButton = new System.Windows.Forms.Button();
            this.totalPayLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // amountOfDaysLabel
            // 
            this.amountOfDaysLabel.AutoSize = true;
            this.amountOfDaysLabel.Location = new System.Drawing.Point(38, 37);
            this.amountOfDaysLabel.Name = "amountOfDaysLabel";
            this.amountOfDaysLabel.Size = new System.Drawing.Size(159, 17);
            this.amountOfDaysLabel.TabIndex = 0;
            this.amountOfDaysLabel.Text = "Amount of days worked:";
            // 
            // amountOfDaysTextBox
            // 
            this.amountOfDaysTextBox.Location = new System.Drawing.Point(203, 37);
            this.amountOfDaysTextBox.Name = "amountOfDaysTextBox";
            this.amountOfDaysTextBox.Size = new System.Drawing.Size(100, 22);
            this.amountOfDaysTextBox.TabIndex = 1;
            // 
            // calculatePayButton
            // 
            this.calculatePayButton.Location = new System.Drawing.Point(140, 189);
            this.calculatePayButton.Name = "calculatePayButton";
            this.calculatePayButton.Size = new System.Drawing.Size(75, 23);
            this.calculatePayButton.TabIndex = 2;
            this.calculatePayButton.Text = "Calculate Pay";
            this.calculatePayButton.UseVisualStyleBackColor = true;
            this.calculatePayButton.Click += new System.EventHandler(this.calculatePayButton_Click);
            // 
            // totalPayLabel
            // 
            this.totalPayLabel.AutoSize = true;
            this.totalPayLabel.Location = new System.Drawing.Point(41, 67);
            this.totalPayLabel.Name = "totalPayLabel";
            this.totalPayLabel.Size = new System.Drawing.Size(128, 17);
            this.totalPayLabel.TabIndex = 3;
            this.totalPayLabel.Text = "Total Amount Paid:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.totalPayLabel);
            this.Controls.Add(this.calculatePayButton);
            this.Controls.Add(this.amountOfDaysTextBox);
            this.Controls.Add(this.amountOfDaysLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label amountOfDaysLabel;
        private System.Windows.Forms.TextBox amountOfDaysTextBox;
        private System.Windows.Forms.Button calculatePayButton;
        private System.Windows.Forms.Label totalPayLabel;
    }
}

