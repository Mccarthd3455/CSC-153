﻿
namespace M1HW3_MccarthD3455
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.propertyValueLabel = new System.Windows.Forms.Label();
            this.propertyValueTextBox = new System.Windows.Forms.TextBox();
            this.propertyTaxLabel = new System.Windows.Forms.Label();
            this.propertyTaxAnswerLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // propertyValueLabel
            // 
            this.propertyValueLabel.AutoSize = true;
            this.propertyValueLabel.Location = new System.Drawing.Point(40, 30);
            this.propertyValueLabel.Name = "propertyValueLabel";
            this.propertyValueLabel.Size = new System.Drawing.Size(178, 13);
            this.propertyValueLabel.TabIndex = 0;
            this.propertyValueLabel.Text = "What is the value of your property? :";
            // 
            // propertyValueTextBox
            // 
            this.propertyValueTextBox.Location = new System.Drawing.Point(224, 27);
            this.propertyValueTextBox.Name = "propertyValueTextBox";
            this.propertyValueTextBox.Size = new System.Drawing.Size(100, 20);
            this.propertyValueTextBox.TabIndex = 1;
            // 
            // propertyTaxLabel
            // 
            this.propertyTaxLabel.AutoSize = true;
            this.propertyTaxLabel.Location = new System.Drawing.Point(40, 57);
            this.propertyTaxLabel.Name = "propertyTaxLabel";
            this.propertyTaxLabel.Size = new System.Drawing.Size(70, 13);
            this.propertyTaxLabel.TabIndex = 2;
            this.propertyTaxLabel.Text = "Property Tax:";
            // 
            // propertyTaxAnswerLabel
            // 
            this.propertyTaxAnswerLabel.AutoSize = true;
            this.propertyTaxAnswerLabel.Location = new System.Drawing.Point(117, 57);
            this.propertyTaxAnswerLabel.Name = "propertyTaxAnswerLabel";
            this.propertyTaxAnswerLabel.Size = new System.Drawing.Size(0, 13);
            this.propertyTaxAnswerLabel.TabIndex = 3;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(43, 95);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(151, 23);
            this.calculateButton.TabIndex = 4;
            this.calculateButton.Text = "Calculate Tax";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.propertyTaxAnswerLabel);
            this.Controls.Add(this.propertyTaxLabel);
            this.Controls.Add(this.propertyValueTextBox);
            this.Controls.Add(this.propertyValueLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label propertyValueLabel;
        private System.Windows.Forms.TextBox propertyValueTextBox;
        private System.Windows.Forms.Label propertyTaxLabel;
        private System.Windows.Forms.Label propertyTaxAnswerLabel;
        private System.Windows.Forms.Button calculateButton;
    }
}

