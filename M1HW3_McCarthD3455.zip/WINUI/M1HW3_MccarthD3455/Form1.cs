﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW3_MccarthD3455
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            /**
            * 2/1/2023
            * CSC 153
            * David McCarthy
            * This program ask the user for their property's value and then calculates the property's sale tax.
            */
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            Double propertyValue;
            Double propertyTax;

            propertyValue = double.Parse(propertyValueTextBox.Text);
            propertyTax = ((propertyValue / 100) * 0.64);
            propertyTaxAnswerLabel.Text = propertyTax.ToString("C");

        }
    }
}
