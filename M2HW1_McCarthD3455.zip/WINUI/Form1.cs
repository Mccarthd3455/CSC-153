﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WINUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            /**
            * 2/8/2023
            * CSC 153
            * David McCarthy
            *This program allows the user to select 2 colors from 2 different groups of radio buttons then mixes the
            *colors to create the new background color
            */
        }
        private void mixButton_Click(object sender, EventArgs e)
        {
            if (firstRedRadioButton.Checked && secondRedRadioButton.Checked)
            {
                this.BackColor = Color.Red;
            }
            else if (firstRedRadioButton.Checked && secondBlueRadioButton.Checked)
            {
                this.BackColor = Color.Purple;
            }
            else if (firstRedRadioButton.Checked && secondYellowRadioButton.Checked)
            {
                this.BackColor = Color.Orange;
            }
            else if (firstBlueRadioButton.Checked && secondBlueRadioButton.Checked)
            {
                this.BackColor = Color.Blue;
            }
            else if (firstBlueRadioButton.Checked && secondRedRadioButton.Checked)
            {
                this.BackColor = Color.Purple;
            }
            else if (firstBlueRadioButton.Checked && secondYellowRadioButton.Checked)
            {
                this.BackColor = Color.Green;
            }
            else if (firstYellowRadioButton.Checked && secondYellowRadioButton.Checked)
            {
                this.BackColor = Color.Yellow;
            }
            else if (firstYellowRadioButton.Checked && secondRedRadioButton.Checked)
            {
                this.BackColor = Color.Orange;
            }
            else if (firstYellowRadioButton.Checked && secondBlueRadioButton.Checked)
            {
                this.BackColor = Color.Green;
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
