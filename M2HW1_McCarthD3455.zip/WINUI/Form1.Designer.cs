﻿
namespace WINUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.firstRedRadioButton = new System.Windows.Forms.RadioButton();
            this.firstBlueRadioButton = new System.Windows.Forms.RadioButton();
            this.firstYellowRadioButton = new System.Windows.Forms.RadioButton();
            this.secondRedRadioButton = new System.Windows.Forms.RadioButton();
            this.secondBlueRadioButton = new System.Windows.Forms.RadioButton();
            this.secondYellowRadioButton = new System.Windows.Forms.RadioButton();
            this.mixButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.HighlightText;
            this.groupBox1.Controls.Add(this.firstYellowRadioButton);
            this.groupBox1.Controls.Add(this.firstBlueRadioButton);
            this.groupBox1.Controls.Add(this.firstRedRadioButton);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "First Color";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.groupBox2.Controls.Add(this.secondYellowRadioButton);
            this.groupBox2.Controls.Add(this.secondBlueRadioButton);
            this.groupBox2.Controls.Add(this.secondRedRadioButton);
            this.groupBox2.Location = new System.Drawing.Point(257, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 100);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Second Color";
            // 
            // firstRedRadioButton
            // 
            this.firstRedRadioButton.AutoSize = true;
            this.firstRedRadioButton.Location = new System.Drawing.Point(7, 22);
            this.firstRedRadioButton.Name = "firstRedRadioButton";
            this.firstRedRadioButton.Size = new System.Drawing.Size(55, 21);
            this.firstRedRadioButton.TabIndex = 0;
            this.firstRedRadioButton.TabStop = true;
            this.firstRedRadioButton.Text = "Red";
            this.firstRedRadioButton.UseVisualStyleBackColor = true;
            // 
            // firstBlueRadioButton
            // 
            this.firstBlueRadioButton.AutoSize = true;
            this.firstBlueRadioButton.Location = new System.Drawing.Point(7, 46);
            this.firstBlueRadioButton.Name = "firstBlueRadioButton";
            this.firstBlueRadioButton.Size = new System.Drawing.Size(57, 21);
            this.firstBlueRadioButton.TabIndex = 1;
            this.firstBlueRadioButton.TabStop = true;
            this.firstBlueRadioButton.Text = "Blue";
            this.firstBlueRadioButton.UseVisualStyleBackColor = true;
            // 
            // firstYellowRadioButton
            // 
            this.firstYellowRadioButton.AutoSize = true;
            this.firstYellowRadioButton.Location = new System.Drawing.Point(7, 73);
            this.firstYellowRadioButton.Name = "firstYellowRadioButton";
            this.firstYellowRadioButton.Size = new System.Drawing.Size(69, 21);
            this.firstYellowRadioButton.TabIndex = 2;
            this.firstYellowRadioButton.TabStop = true;
            this.firstYellowRadioButton.Text = "Yellow";
            this.firstYellowRadioButton.UseVisualStyleBackColor = true;
            // 
            // secondRedRadioButton
            // 
            this.secondRedRadioButton.AutoSize = true;
            this.secondRedRadioButton.Location = new System.Drawing.Point(7, 22);
            this.secondRedRadioButton.Name = "secondRedRadioButton";
            this.secondRedRadioButton.Size = new System.Drawing.Size(55, 21);
            this.secondRedRadioButton.TabIndex = 0;
            this.secondRedRadioButton.TabStop = true;
            this.secondRedRadioButton.Text = "Red";
            this.secondRedRadioButton.UseVisualStyleBackColor = true;
            // 
            // secondBlueRadioButton
            // 
            this.secondBlueRadioButton.AutoSize = true;
            this.secondBlueRadioButton.Location = new System.Drawing.Point(7, 46);
            this.secondBlueRadioButton.Name = "secondBlueRadioButton";
            this.secondBlueRadioButton.Size = new System.Drawing.Size(57, 21);
            this.secondBlueRadioButton.TabIndex = 1;
            this.secondBlueRadioButton.TabStop = true;
            this.secondBlueRadioButton.Text = "Blue";
            this.secondBlueRadioButton.UseVisualStyleBackColor = true;
            // 
            // secondYellowRadioButton
            // 
            this.secondYellowRadioButton.AutoSize = true;
            this.secondYellowRadioButton.Location = new System.Drawing.Point(7, 73);
            this.secondYellowRadioButton.Name = "secondYellowRadioButton";
            this.secondYellowRadioButton.Size = new System.Drawing.Size(69, 21);
            this.secondYellowRadioButton.TabIndex = 2;
            this.secondYellowRadioButton.TabStop = true;
            this.secondYellowRadioButton.Text = "Yellow";
            this.secondYellowRadioButton.UseVisualStyleBackColor = true;
            // 
            // mixButton
            // 
            this.mixButton.Location = new System.Drawing.Point(118, 138);
            this.mixButton.Name = "mixButton";
            this.mixButton.Size = new System.Drawing.Size(75, 23);
            this.mixButton.TabIndex = 2;
            this.mixButton.Text = "Mix";
            this.mixButton.UseVisualStyleBackColor = true;
            this.mixButton.Click += new System.EventHandler(this.mixButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(264, 138);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(77, 24);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.mixButton);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton firstYellowRadioButton;
        private System.Windows.Forms.RadioButton firstBlueRadioButton;
        private System.Windows.Forms.RadioButton firstRedRadioButton;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton secondYellowRadioButton;
        private System.Windows.Forms.RadioButton secondBlueRadioButton;
        private System.Windows.Forms.RadioButton secondRedRadioButton;
        private System.Windows.Forms.Button mixButton;
        private System.Windows.Forms.Button exitButton;
    }
}

