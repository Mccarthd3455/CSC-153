﻿
namespace WINUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelFn = new System.Windows.Forms.Label();
            this.labelMn = new System.Windows.Forms.Label();
            this.labelLn = new System.Windows.Forms.Label();
            this.labelTitle = new System.Windows.Forms.Label();
            this.userFnTextBox = new System.Windows.Forms.TextBox();
            this.userMnTextBox = new System.Windows.Forms.TextBox();
            this.userLnTextBox = new System.Windows.Forms.TextBox();
            this.userTitleTextBox = new System.Windows.Forms.TextBox();
            this.fullNameWithTitle = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.userFullNameTextBox = new System.Windows.Forms.TextBox();
            this.userFullNameButton = new System.Windows.Forms.Button();
            this.userFullNameNoMiddleButton = new System.Windows.Forms.Button();
            this.userLastNameFirstTitleButton = new System.Windows.Forms.Button();
            this.userLastNameFirstFullName = new System.Windows.Forms.Button();
            this.userLastNameFirstNoTitleMiddle = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelFn
            // 
            this.labelFn.AutoSize = true;
            this.labelFn.Location = new System.Drawing.Point(29, 33);
            this.labelFn.Name = "labelFn";
            this.labelFn.Size = new System.Drawing.Size(157, 17);
            this.labelFn.TabIndex = 0;
            this.labelFn.Text = "What\'s your first name?";
            // 
            // labelMn
            // 
            this.labelMn.AutoSize = true;
            this.labelMn.Location = new System.Drawing.Point(29, 70);
            this.labelMn.Name = "labelMn";
            this.labelMn.Size = new System.Drawing.Size(175, 17);
            this.labelMn.TabIndex = 1;
            this.labelMn.Text = "What\'s your middle name?";
            // 
            // labelLn
            // 
            this.labelLn.AutoSize = true;
            this.labelLn.Location = new System.Drawing.Point(29, 104);
            this.labelLn.Name = "labelLn";
            this.labelLn.Size = new System.Drawing.Size(156, 17);
            this.labelLn.TabIndex = 2;
            this.labelLn.Text = "What\'s your last name?";
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Location = new System.Drawing.Point(29, 140);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(117, 17);
            this.labelTitle.TabIndex = 3;
            this.labelTitle.Text = "What\'s your title?";
            // 
            // userFnTextBox
            // 
            this.userFnTextBox.Location = new System.Drawing.Point(193, 33);
            this.userFnTextBox.Name = "userFnTextBox";
            this.userFnTextBox.Size = new System.Drawing.Size(100, 22);
            this.userFnTextBox.TabIndex = 4;
            // 
            // userMnTextBox
            // 
            this.userMnTextBox.Location = new System.Drawing.Point(211, 70);
            this.userMnTextBox.Name = "userMnTextBox";
            this.userMnTextBox.Size = new System.Drawing.Size(100, 22);
            this.userMnTextBox.TabIndex = 5;
            // 
            // userLnTextBox
            // 
            this.userLnTextBox.Location = new System.Drawing.Point(192, 104);
            this.userLnTextBox.Name = "userLnTextBox";
            this.userLnTextBox.Size = new System.Drawing.Size(100, 22);
            this.userLnTextBox.TabIndex = 6;
            // 
            // userTitleTextBox
            // 
            this.userTitleTextBox.Location = new System.Drawing.Point(153, 140);
            this.userTitleTextBox.Name = "userTitleTextBox";
            this.userTitleTextBox.Size = new System.Drawing.Size(100, 22);
            this.userTitleTextBox.TabIndex = 7;
            // 
            // fullNameWithTitle
            // 
            this.fullNameWithTitle.Location = new System.Drawing.Point(32, 297);
            this.fullNameWithTitle.Name = "fullNameWithTitle";
            this.fullNameWithTitle.Size = new System.Drawing.Size(91, 49);
            this.fullNameWithTitle.TabIndex = 8;
            this.fullNameWithTitle.Text = "Full name with title";
            this.fullNameWithTitle.UseVisualStyleBackColor = true;
            this.fullNameWithTitle.Click += new System.EventHandler(this.fullNameWithTitle_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 194);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 17);
            this.label1.TabIndex = 9;
            this.label1.Text = "This is your name formatted:";
            // 
            // userFullNameTextBox
            // 
            this.userFullNameTextBox.Location = new System.Drawing.Point(226, 191);
            this.userFullNameTextBox.Name = "userFullNameTextBox";
            this.userFullNameTextBox.Size = new System.Drawing.Size(297, 22);
            this.userFullNameTextBox.TabIndex = 10;
            // 
            // userFullNameButton
            // 
            this.userFullNameButton.Location = new System.Drawing.Point(128, 297);
            this.userFullNameButton.Name = "userFullNameButton";
            this.userFullNameButton.Size = new System.Drawing.Size(75, 48);
            this.userFullNameButton.TabIndex = 11;
            this.userFullNameButton.Text = "Full Name";
            this.userFullNameButton.UseVisualStyleBackColor = true;
            this.userFullNameButton.Click += new System.EventHandler(this.userFullNameButton_Click);
            // 
            // userFullNameNoMiddleButton
            // 
            this.userFullNameNoMiddleButton.Location = new System.Drawing.Point(209, 297);
            this.userFullNameNoMiddleButton.Name = "userFullNameNoMiddleButton";
            this.userFullNameNoMiddleButton.Size = new System.Drawing.Size(124, 48);
            this.userFullNameNoMiddleButton.TabIndex = 12;
            this.userFullNameNoMiddleButton.Text = "Full Name Without Middle";
            this.userFullNameNoMiddleButton.UseVisualStyleBackColor = true;
            this.userFullNameNoMiddleButton.Click += new System.EventHandler(this.userFullNameNoMiddleButton_Click);
            // 
            // userLastNameFirstTitleButton
            // 
            this.userLastNameFirstTitleButton.Location = new System.Drawing.Point(339, 297);
            this.userLastNameFirstTitleButton.Name = "userLastNameFirstTitleButton";
            this.userLastNameFirstTitleButton.Size = new System.Drawing.Size(121, 47);
            this.userLastNameFirstTitleButton.TabIndex = 13;
            this.userLastNameFirstTitleButton.Text = "Last Name FIrst with Title";
            this.userLastNameFirstTitleButton.UseVisualStyleBackColor = true;
            this.userLastNameFirstTitleButton.Click += new System.EventHandler(this.userLastNameFirstTitleButton_Click);
            // 
            // userLastNameFirstFullName
            // 
            this.userLastNameFirstFullName.Location = new System.Drawing.Point(466, 297);
            this.userLastNameFirstFullName.Name = "userLastNameFirstFullName";
            this.userLastNameFirstFullName.Size = new System.Drawing.Size(121, 47);
            this.userLastNameFirstFullName.TabIndex = 14;
            this.userLastNameFirstFullName.Text = "Last Name first without Title";
            this.userLastNameFirstFullName.UseVisualStyleBackColor = true;
            this.userLastNameFirstFullName.Click += new System.EventHandler(this.userLastNameFirstFullName_Click);
            // 
            // userLastNameFirstNoTitleMiddle
            // 
            this.userLastNameFirstNoTitleMiddle.Location = new System.Drawing.Point(593, 297);
            this.userLastNameFirstNoTitleMiddle.Name = "userLastNameFirstNoTitleMiddle";
            this.userLastNameFirstNoTitleMiddle.Size = new System.Drawing.Size(169, 46);
            this.userLastNameFirstNoTitleMiddle.TabIndex = 15;
            this.userLastNameFirstNoTitleMiddle.Text = "Last Name first without middle and title";
            this.userLastNameFirstNoTitleMiddle.UseVisualStyleBackColor = true;
            this.userLastNameFirstNoTitleMiddle.Click += new System.EventHandler(this.userLastNameFirstNoTitleMiddle_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.userLastNameFirstNoTitleMiddle);
            this.Controls.Add(this.userLastNameFirstFullName);
            this.Controls.Add(this.userLastNameFirstTitleButton);
            this.Controls.Add(this.userFullNameNoMiddleButton);
            this.Controls.Add(this.userFullNameButton);
            this.Controls.Add(this.userFullNameTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.fullNameWithTitle);
            this.Controls.Add(this.userTitleTextBox);
            this.Controls.Add(this.userLnTextBox);
            this.Controls.Add(this.userMnTextBox);
            this.Controls.Add(this.userFnTextBox);
            this.Controls.Add(this.labelTitle);
            this.Controls.Add(this.labelLn);
            this.Controls.Add(this.labelMn);
            this.Controls.Add(this.labelFn);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelFn;
        private System.Windows.Forms.Label labelMn;
        private System.Windows.Forms.Label labelLn;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.TextBox userFnTextBox;
        private System.Windows.Forms.TextBox userMnTextBox;
        private System.Windows.Forms.TextBox userLnTextBox;
        private System.Windows.Forms.TextBox userTitleTextBox;
        private System.Windows.Forms.Button fullNameWithTitle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox userFullNameTextBox;
        private System.Windows.Forms.Button userFullNameButton;
        private System.Windows.Forms.Button userFullNameNoMiddleButton;
        private System.Windows.Forms.Button userLastNameFirstTitleButton;
        private System.Windows.Forms.Button userLastNameFirstFullName;
        private System.Windows.Forms.Button userLastNameFirstNoTitleMiddle;
    }
}

