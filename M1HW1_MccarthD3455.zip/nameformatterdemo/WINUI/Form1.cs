﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WINUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void fullNameWithTitle_Click(object sender, EventArgs e)
        {
            String userFullNameWithTitle;
            userFullNameWithTitle = userTitleTextBox.Text + ". " + userFnTextBox.Text + " " + userMnTextBox.Text + " " + userLnTextBox.Text;
            userFullNameTextBox.Text = userFullNameWithTitle;
        }

        private void userFullNameButton_Click(object sender, EventArgs e)
        {
            String userFullNameWithTitle;
            userFullNameWithTitle = userFnTextBox.Text + " " + userMnTextBox.Text + " " + userLnTextBox.Text;
            userFullNameTextBox.Text = userFullNameWithTitle;
        }

        private void userFullNameNoMiddleButton_Click(object sender, EventArgs e)
        {
            String userFullNameWithTitle;
            userFullNameWithTitle =  userFnTextBox.Text + " " + userLnTextBox.Text;
            userFullNameTextBox.Text = userFullNameWithTitle;
        }

        private void userLastNameFirstTitleButton_Click(object sender, EventArgs e)
        {
            String userFullNameWithTitle;
            userFullNameWithTitle = userLnTextBox.Text + ", " + userFnTextBox.Text + " " + userMnTextBox.Text + ", " + userTitleTextBox.Text + ".";
            userFullNameTextBox.Text = userFullNameWithTitle;
        }

        private void userLastNameFirstFullName_Click(object sender, EventArgs e)
        {
            String userFullNameWithTitle;
            userFullNameWithTitle = userLnTextBox.Text + ", " + userFnTextBox.Text + " " + userMnTextBox.Text;
            userFullNameTextBox.Text = userFullNameWithTitle;
        }

        private void userLastNameFirstNoTitleMiddle_Click(object sender, EventArgs e)
        {
            String userFullNameWithTitle;
            userFullNameWithTitle = userLnTextBox.Text + ", " + userFnTextBox.Text;
            userFullNameTextBox.Text = userFullNameWithTitle;
        }
    }
}
