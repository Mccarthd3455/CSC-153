﻿ using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WINUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void createFileButton_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            int i = 0;
            int amountRandomNum = 0;
            int randomNumber;
            string randomNumberString;
            StreamWriter outputFile;
            amountRandomNum = int.Parse(randomNumberTextBox.Text);
            saveFile.ShowDialog();
            
            if(saveFile.ShowDialog() == DialogResult.OK)
            { 
                outputFile = File.CreateText(saveFile.FileName + ".txt");

                for (i = 1; i <= amountRandomNum; i++)
                {
                    randomNumber = rand.Next(1, 101);
                    randomNumberString = randomNumber.ToString();
                    outputFile.WriteLine(randomNumberString);
                }
                outputFile.Close();
                saveFile.FileName = " ";
                MessageBox.Show("File was saved.");
            }
            
        }
    }
}
