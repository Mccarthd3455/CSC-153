﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Employee_Class_Library;

/**
* 4/30/23
* CSC 153
* David McCarthy
* Creates an employee class and creates an employee object for 3 employees and then prints them
*/
namespace WINUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Employee employee1 = new Employee();
            employee1.Name = "Susan Meyers";
            employee1.ID = 48799;
            employee1.Department = "Accounting";
            employee1.Position = "Vice President";

            Employee employee2 = new Employee();
            employee2.Name = "Mark Jones";
            employee2.ID = 39119;
            employee2.Department = "IT";
            employee2.Position = "Programmer";

            Employee employee3 = new Employee(); 
            employee3.Name = "Joy Rogers";
            employee3.ID = 81774;
            employee3.Department = "Manufacturing";
            employee3.Position = "Engineer";

            employee1Label.Text = employee1.Name + " " + employee1.ID.ToString() + " " + employee1.Department + " " + employee1.Position;

            employee2Label.Text = employee2.Name + " " + employee2.ID.ToString() + " " + employee2.Department + " " + employee2.Position;

            employee3Label.Text = employee3.Name + " " + employee3.ID.ToString() + " " + employee3.Department + " " + employee3.Position;
        }
    }
}
