﻿
namespace WINUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.employee1Label = new System.Windows.Forms.Label();
            this.employee2Label = new System.Windows.Forms.Label();
            this.employee3Label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // employee1Label
            // 
            this.employee1Label.AutoSize = true;
            this.employee1Label.Location = new System.Drawing.Point(61, 33);
            this.employee1Label.Name = "employee1Label";
            this.employee1Label.Size = new System.Drawing.Size(0, 17);
            this.employee1Label.TabIndex = 0;
            // 
            // employee2Label
            // 
            this.employee2Label.AutoSize = true;
            this.employee2Label.Location = new System.Drawing.Point(64, 68);
            this.employee2Label.Name = "employee2Label";
            this.employee2Label.Size = new System.Drawing.Size(0, 17);
            this.employee2Label.TabIndex = 1;
            // 
            // employee3Label
            // 
            this.employee3Label.AutoSize = true;
            this.employee3Label.Location = new System.Drawing.Point(64, 112);
            this.employee3Label.Name = "employee3Label";
            this.employee3Label.Size = new System.Drawing.Size(0, 17);
            this.employee3Label.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.employee3Label);
            this.Controls.Add(this.employee2Label);
            this.Controls.Add(this.employee1Label);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label employee1Label;
        private System.Windows.Forms.Label employee2Label;
        private System.Windows.Forms.Label employee3Label;
    }
}

