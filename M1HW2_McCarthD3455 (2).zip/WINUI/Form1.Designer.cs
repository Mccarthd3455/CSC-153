﻿
namespace WINUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.wallLengthTextBox = new System.Windows.Forms.TextBox();
            this.wallWidthTextBox = new System.Windows.Forms.TextBox();
            this.wallAreaLabel = new System.Windows.Forms.Label();
            this.wallAreaLabelAnswer = new System.Windows.Forms.Label();
            this.areaCalculatorButton = new System.Windows.Forms.Button();
            this.paintGallonsLabel = new System.Windows.Forms.Label();
            this.paintGallonsAnswerLabel = new System.Windows.Forms.Label();
            this.laborHoursNeeded = new System.Windows.Forms.Label();
            this.laborHoursAnswer = new System.Windows.Forms.Label();
            this.paintCostLabel = new System.Windows.Forms.Label();
            this.laborCostLabel = new System.Windows.Forms.Label();
            this.laborCostAnswerLabel = new System.Windows.Forms.Label();
            this.totalCostLabel = new System.Windows.Forms.Label();
            this.totalCostAnswerLabel = new System.Windows.Forms.Label();
            this.calculatePrice = new System.Windows.Forms.Button();
            this.paintCostTextBox = new System.Windows.Forms.TextBox();
            this.totalCostOfPaintLabel = new System.Windows.Forms.Label();
            this.totalCostOfPaintAnswerLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Length of the wall in feet: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(158, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Width of the wall in feet:";
            // 
            // wallLengthTextBox
            // 
            this.wallLengthTextBox.Location = new System.Drawing.Point(200, 26);
            this.wallLengthTextBox.Name = "wallLengthTextBox";
            this.wallLengthTextBox.Size = new System.Drawing.Size(100, 22);
            this.wallLengthTextBox.TabIndex = 2;
            // 
            // wallWidthTextBox
            // 
            this.wallWidthTextBox.Location = new System.Drawing.Point(200, 59);
            this.wallWidthTextBox.Name = "wallWidthTextBox";
            this.wallWidthTextBox.Size = new System.Drawing.Size(100, 22);
            this.wallWidthTextBox.TabIndex = 3;
            // 
            // wallAreaLabel
            // 
            this.wallAreaLabel.AutoSize = true;
            this.wallAreaLabel.Location = new System.Drawing.Point(23, 91);
            this.wallAreaLabel.Name = "wallAreaLabel";
            this.wallAreaLabel.Size = new System.Drawing.Size(42, 17);
            this.wallAreaLabel.TabIndex = 4;
            this.wallAreaLabel.Text = "Area:";
            // 
            // wallAreaLabelAnswer
            // 
            this.wallAreaLabelAnswer.AutoSize = true;
            this.wallAreaLabelAnswer.Location = new System.Drawing.Point(71, 91);
            this.wallAreaLabelAnswer.Name = "wallAreaLabelAnswer";
            this.wallAreaLabelAnswer.Size = new System.Drawing.Size(0, 17);
            this.wallAreaLabelAnswer.TabIndex = 5;
            // 
            // areaCalculatorButton
            // 
            this.areaCalculatorButton.Location = new System.Drawing.Point(55, 124);
            this.areaCalculatorButton.Name = "areaCalculatorButton";
            this.areaCalculatorButton.Size = new System.Drawing.Size(222, 23);
            this.areaCalculatorButton.TabIndex = 6;
            this.areaCalculatorButton.Text = "Calculate the Area of the Wall";
            this.areaCalculatorButton.UseVisualStyleBackColor = true;
            this.areaCalculatorButton.Click += new System.EventHandler(this.areaCalculatorButton_Click);
            // 
            // paintGallonsLabel
            // 
            this.paintGallonsLabel.AutoSize = true;
            this.paintGallonsLabel.Location = new System.Drawing.Point(23, 180);
            this.paintGallonsLabel.Name = "paintGallonsLabel";
            this.paintGallonsLabel.Size = new System.Drawing.Size(163, 17);
            this.paintGallonsLabel.TabIndex = 7;
            this.paintGallonsLabel.Text = "Gallons of paint needed:";
            // 
            // paintGallonsAnswerLabel
            // 
            this.paintGallonsAnswerLabel.AutoSize = true;
            this.paintGallonsAnswerLabel.Location = new System.Drawing.Point(196, 180);
            this.paintGallonsAnswerLabel.Name = "paintGallonsAnswerLabel";
            this.paintGallonsAnswerLabel.Size = new System.Drawing.Size(0, 17);
            this.paintGallonsAnswerLabel.TabIndex = 8;
            // 
            // laborHoursNeeded
            // 
            this.laborHoursNeeded.AutoSize = true;
            this.laborHoursNeeded.Location = new System.Drawing.Point(23, 213);
            this.laborHoursNeeded.Name = "laborHoursNeeded";
            this.laborHoursNeeded.Size = new System.Drawing.Size(163, 17);
            this.laborHoursNeeded.TabIndex = 9;
            this.laborHoursNeeded.Text = "Hours of Labor needed: ";
            // 
            // laborHoursAnswer
            // 
            this.laborHoursAnswer.AutoSize = true;
            this.laborHoursAnswer.Location = new System.Drawing.Point(196, 213);
            this.laborHoursAnswer.Name = "laborHoursAnswer";
            this.laborHoursAnswer.Size = new System.Drawing.Size(0, 17);
            this.laborHoursAnswer.TabIndex = 10;
            // 
            // paintCostLabel
            // 
            this.paintCostLabel.AutoSize = true;
            this.paintCostLabel.Location = new System.Drawing.Point(23, 242);
            this.paintCostLabel.Name = "paintCostLabel";
            this.paintCostLabel.Size = new System.Drawing.Size(92, 17);
            this.paintCostLabel.TabIndex = 11;
            this.paintCostLabel.Text = "Cost of Paint:";
            // 
            // laborCostLabel
            // 
            this.laborCostLabel.AutoSize = true;
            this.laborCostLabel.Location = new System.Drawing.Point(23, 304);
            this.laborCostLabel.Name = "laborCostLabel";
            this.laborCostLabel.Size = new System.Drawing.Size(97, 17);
            this.laborCostLabel.TabIndex = 13;
            this.laborCostLabel.Text = "Cost of Labor:";
            // 
            // laborCostAnswerLabel
            // 
            this.laborCostAnswerLabel.AutoSize = true;
            this.laborCostAnswerLabel.Location = new System.Drawing.Point(126, 304);
            this.laborCostAnswerLabel.Name = "laborCostAnswerLabel";
            this.laborCostAnswerLabel.Size = new System.Drawing.Size(0, 17);
            this.laborCostAnswerLabel.TabIndex = 14;
            // 
            // totalCostLabel
            // 
            this.totalCostLabel.AutoSize = true;
            this.totalCostLabel.Location = new System.Drawing.Point(23, 334);
            this.totalCostLabel.Name = "totalCostLabel";
            this.totalCostLabel.Size = new System.Drawing.Size(76, 17);
            this.totalCostLabel.TabIndex = 15;
            this.totalCostLabel.Text = "Total Cost:";
            // 
            // totalCostAnswerLabel
            // 
            this.totalCostAnswerLabel.AutoSize = true;
            this.totalCostAnswerLabel.Location = new System.Drawing.Point(105, 334);
            this.totalCostAnswerLabel.Name = "totalCostAnswerLabel";
            this.totalCostAnswerLabel.Size = new System.Drawing.Size(0, 17);
            this.totalCostAnswerLabel.TabIndex = 16;
            // 
            // calculatePrice
            // 
            this.calculatePrice.Location = new System.Drawing.Point(55, 374);
            this.calculatePrice.Name = "calculatePrice";
            this.calculatePrice.Size = new System.Drawing.Size(222, 23);
            this.calculatePrice.TabIndex = 17;
            this.calculatePrice.Text = "Calculate Price";
            this.calculatePrice.UseVisualStyleBackColor = true;
            this.calculatePrice.Click += new System.EventHandler(this.calculatePrice_Click);
            // 
            // paintCostTextBox
            // 
            this.paintCostTextBox.Location = new System.Drawing.Point(122, 242);
            this.paintCostTextBox.Name = "paintCostTextBox";
            this.paintCostTextBox.Size = new System.Drawing.Size(100, 22);
            this.paintCostTextBox.TabIndex = 18;
            // 
            // totalCostOfPaintLabel
            // 
            this.totalCostOfPaintLabel.AutoSize = true;
            this.totalCostOfPaintLabel.Location = new System.Drawing.Point(23, 277);
            this.totalCostOfPaintLabel.Name = "totalCostOfPaintLabel";
            this.totalCostOfPaintLabel.Size = new System.Drawing.Size(128, 17);
            this.totalCostOfPaintLabel.TabIndex = 19;
            this.totalCostOfPaintLabel.Text = "Total Cost of Paint:";
            // 
            // totalCostOfPaintAnswerLabel
            // 
            this.totalCostOfPaintAnswerLabel.AutoSize = true;
            this.totalCostOfPaintAnswerLabel.Location = new System.Drawing.Point(157, 277);
            this.totalCostOfPaintAnswerLabel.Name = "totalCostOfPaintAnswerLabel";
            this.totalCostOfPaintAnswerLabel.Size = new System.Drawing.Size(0, 17);
            this.totalCostOfPaintAnswerLabel.TabIndex = 20;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.totalCostOfPaintAnswerLabel);
            this.Controls.Add(this.totalCostOfPaintLabel);
            this.Controls.Add(this.paintCostTextBox);
            this.Controls.Add(this.calculatePrice);
            this.Controls.Add(this.totalCostAnswerLabel);
            this.Controls.Add(this.totalCostLabel);
            this.Controls.Add(this.laborCostAnswerLabel);
            this.Controls.Add(this.laborCostLabel);
            this.Controls.Add(this.paintCostLabel);
            this.Controls.Add(this.laborHoursAnswer);
            this.Controls.Add(this.laborHoursNeeded);
            this.Controls.Add(this.paintGallonsAnswerLabel);
            this.Controls.Add(this.paintGallonsLabel);
            this.Controls.Add(this.areaCalculatorButton);
            this.Controls.Add(this.wallAreaLabelAnswer);
            this.Controls.Add(this.wallAreaLabel);
            this.Controls.Add(this.wallWidthTextBox);
            this.Controls.Add(this.wallLengthTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox wallLengthTextBox;
        private System.Windows.Forms.TextBox wallWidthTextBox;
        private System.Windows.Forms.Label wallAreaLabel;
        private System.Windows.Forms.Label wallAreaLabelAnswer;
        private System.Windows.Forms.Button areaCalculatorButton;
        private System.Windows.Forms.Label paintGallonsLabel;
        private System.Windows.Forms.Label paintGallonsAnswerLabel;
        private System.Windows.Forms.Label laborHoursNeeded;
        private System.Windows.Forms.Label laborHoursAnswer;
        private System.Windows.Forms.Label paintCostLabel;
        private System.Windows.Forms.Label laborCostLabel;
        private System.Windows.Forms.Label laborCostAnswerLabel;
        private System.Windows.Forms.Label totalCostLabel;
        private System.Windows.Forms.Label totalCostAnswerLabel;
        private System.Windows.Forms.Button calculatePrice;
        private System.Windows.Forms.TextBox paintCostTextBox;
        private System.Windows.Forms.Label totalCostOfPaintLabel;
        private System.Windows.Forms.Label totalCostOfPaintAnswerLabel;
    }
}

