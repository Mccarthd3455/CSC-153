﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 1/20/23
* CSC 153
* David McCarthy
* Gets User input for length and width of the wall then calculates the area of the wall and does calculations for 
* how many gallons of paint are needed for the wall and how many labor hours it will take. Finally it calculates the 
* price of the gallons and labor prices and adds them together to get the final price.
*/
namespace WINUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void areaCalculatorButton_Click(object sender, EventArgs e)
        {
            double wallArea;
            double wallLength;
            double wallWidth;
            wallLength = double.Parse(wallLengthTextBox.Text); //Converts user input to double
            wallWidth = double.Parse(wallWidthTextBox.Text); //Converts user input to double
            wallArea = wallLength * wallWidth; //Calculates the Area 
            wallAreaLabelAnswer.Text = wallArea.ToString(); //Converts the area into a string to place in the label
        }

        private void calculatePrice_Click(object sender, EventArgs e)
        {
            double wallArea;
            double paintGallons;
            double laborHours;
            double paintGallonsCost;
            double paintGallonsCostTotal;
            double laborCost;
            double totalCost;
           
            wallArea = double.Parse(wallAreaLabelAnswer.Text);
            paintGallons = wallArea / 115 * 1; //Calculate amount of paint needed 
            paintGallonsAnswerLabel.Text = paintGallons.ToString("n2"); //Converts answer into number format

            laborHours = wallArea / 115 * 8;//Calculates labor hours
            laborHoursAnswer.Text = laborHours.ToString("n2"); //Converts answer into number format

            paintGallonsCost = double.Parse(paintCostTextBox.Text);
            paintGallonsCostTotal = paintGallonsCost * paintGallons; //Calculates Total Price of Paint
            totalCostOfPaintAnswerLabel.Text = paintGallonsCostTotal.ToString("C");//Writes the answer in the answer slot


            laborCost = 20.00 * laborHours; //Calculates Total Price of labor
            laborCostAnswerLabel.Text = laborCost.ToString("C"); //Formats answer to Currency format

            totalCost = laborCost + paintGallonsCostTotal;//Calculates total price
            totalCostAnswerLabel.Text = totalCost.ToString("C"); //Formats answer to Currency format
        }
    }
}
