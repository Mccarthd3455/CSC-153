﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 2/15/2023
* CSC 153
* David McCarthy
* This program allows the user to guess an amount of quarter, dimes, nickels, and pennies that add up to $1.00
*/
namespace WINUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void confirmButton_Click(object sender, EventArgs e)
        {
            int totalPennies = 0;//User's Pennies
            double penniesCost;//Cost of the amount of user's pennies amount
            int totalNickels = 0; //User's Nickels
            double nickelsCost; //Cost of the amount of user's nickels amount
            int totalDimes = 0;//User's Dimes
            double dimesCost;//Cost of the amount of user's dime amount 
            int totalQuarters = 0; //User's Quarters
            double quartersCost; // Cost of the amount of user's quarter amount
            double guessTotalCost; //The user's calculated guess total
            const double totalCost = 1.00; //Amount of money user has to guess

            totalPennies = int.Parse(penniesTextBox.Text); //Converts user input to integer
            penniesCost = totalPennies * 0.01; //Calculations for Pennies cost

            totalNickels = int.Parse(nickelTextBox.Text); //Converts user input to integer
            nickelsCost = totalNickels * 0.05; //Calculations for Nickels cost

            totalDimes = int.Parse(dimesTextBox.Text); //Converts user input to integer
            dimesCost = totalDimes * 0.10; //Calculations for Dimes cost

            totalQuarters = int.Parse(quarterTextBox.Text); //Converts user input to integer
            quartersCost = totalQuarters * 0.25; //Calculations for Quarters cost

            guessTotalCost = penniesCost + nickelsCost + dimesCost + quartersCost; //Calculates the user's guess total

            if (guessTotalCost == totalCost)
            {
                winnerPictureBox.Visible = true; //Makes the correct guess (winner) picture pop up
                guessAmountAnswerLabel.Text = ("Congratulations You've guessed correctly!!! Press Play Again to Play Again");//Winner message appears
            }
            else if (guessTotalCost > totalCost)
            {
                loserPictureBox.Visible = true; //Makes the wrong guess picture pop up
                guessAmountAnswerLabel.Text = ("More than $1.00. Press Play Again to Play Again");//Tells user that there guess was More than $1.00
            }
            else if (guessTotalCost < totalCost)
            {
                guessAmountAnswerLabel.Text = ("Less than $1.00. Press Play Again to Play Again"); //tells user that their guess was Less than $1.00
                loserPictureBox.Visible = true; //Makes the wrong guess picture pop up
            }



            

        }

        private void playAgainButton_Click(object sender, EventArgs e)
        {
            penniesTextBox.Text = ("0");//Resets pennies' textbox to 0
            nickelTextBox.Text = ("0");//Resets nickels' textbox to 0
            dimesTextBox.Text = ("0");//Resets dimes' textbox to 0
            quarterTextBox.Text = ("0");//Resets quarters' textbox to 0
            guessAmountAnswerLabel.Text = (" ");//Resets the guess amount to blank
            loserPictureBox.Visible = false;//Makes loser picture disappear
            winnerPictureBox.Visible = false;//Makes winner picture disappear
        }
    }
}
