﻿
namespace WINUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.gameTitleLabel = new System.Windows.Forms.Label();
            this.quartersLabel = new System.Windows.Forms.Label();
            this.dimesLabel = new System.Windows.Forms.Label();
            this.nickelsLabel = new System.Windows.Forms.Label();
            this.penniesLabel = new System.Windows.Forms.Label();
            this.quarterTextBox = new System.Windows.Forms.TextBox();
            this.dimesTextBox = new System.Windows.Forms.TextBox();
            this.nickelTextBox = new System.Windows.Forms.TextBox();
            this.penniesTextBox = new System.Windows.Forms.TextBox();
            this.winnerPictureBox = new System.Windows.Forms.PictureBox();
            this.loserPictureBox = new System.Windows.Forms.PictureBox();
            this.guessAmountLabel = new System.Windows.Forms.Label();
            this.guessAmountAnswerLabel = new System.Windows.Forms.Label();
            this.confirmButton = new System.Windows.Forms.Button();
            this.playAgainButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.winnerPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loserPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // gameTitleLabel
            // 
            this.gameTitleLabel.AutoSize = true;
            this.gameTitleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.gameTitleLabel.Location = new System.Drawing.Point(373, 11);
            this.gameTitleLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.gameTitleLabel.Name = "gameTitleLabel";
            this.gameTitleLabel.Size = new System.Drawing.Size(205, 20);
            this.gameTitleLabel.TabIndex = 0;
            this.gameTitleLabel.Text = "Change for a Dollar Game";
            // 
            // quartersLabel
            // 
            this.quartersLabel.AutoSize = true;
            this.quartersLabel.Location = new System.Drawing.Point(16, 79);
            this.quartersLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.quartersLabel.Name = "quartersLabel";
            this.quartersLabel.Size = new System.Drawing.Size(122, 17);
            this.quartersLabel.TabIndex = 1;
            this.quartersLabel.Text = "Quarters (0.25¢): ";
            // 
            // dimesLabel
            // 
            this.dimesLabel.AutoSize = true;
            this.dimesLabel.Location = new System.Drawing.Point(16, 159);
            this.dimesLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.dimesLabel.Name = "dimesLabel";
            this.dimesLabel.Size = new System.Drawing.Size(101, 17);
            this.dimesLabel.TabIndex = 2;
            this.dimesLabel.Text = "Dimes (0.10¢):";
            // 
            // nickelsLabel
            // 
            this.nickelsLabel.AutoSize = true;
            this.nickelsLabel.Location = new System.Drawing.Point(16, 234);
            this.nickelsLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nickelsLabel.Name = "nickelsLabel";
            this.nickelsLabel.Size = new System.Drawing.Size(107, 17);
            this.nickelsLabel.TabIndex = 3;
            this.nickelsLabel.Text = "Nickels (0.05¢):";
            // 
            // penniesLabel
            // 
            this.penniesLabel.AutoSize = true;
            this.penniesLabel.Location = new System.Drawing.Point(16, 321);
            this.penniesLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.penniesLabel.Name = "penniesLabel";
            this.penniesLabel.Size = new System.Drawing.Size(109, 17);
            this.penniesLabel.TabIndex = 4;
            this.penniesLabel.Text = "Pennies(0.01¢):";
            // 
            // quarterTextBox
            // 
            this.quarterTextBox.Location = new System.Drawing.Point(144, 75);
            this.quarterTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.quarterTextBox.Name = "quarterTextBox";
            this.quarterTextBox.Size = new System.Drawing.Size(132, 22);
            this.quarterTextBox.TabIndex = 5;
            this.quarterTextBox.Text = "0";
            // 
            // dimesTextBox
            // 
            this.dimesTextBox.Location = new System.Drawing.Point(144, 159);
            this.dimesTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.dimesTextBox.Name = "dimesTextBox";
            this.dimesTextBox.Size = new System.Drawing.Size(132, 22);
            this.dimesTextBox.TabIndex = 6;
            this.dimesTextBox.Text = "0";
            // 
            // nickelTextBox
            // 
            this.nickelTextBox.Location = new System.Drawing.Point(144, 225);
            this.nickelTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.nickelTextBox.Name = "nickelTextBox";
            this.nickelTextBox.Size = new System.Drawing.Size(132, 22);
            this.nickelTextBox.TabIndex = 7;
            this.nickelTextBox.Text = "0";
            // 
            // penniesTextBox
            // 
            this.penniesTextBox.Location = new System.Drawing.Point(144, 321);
            this.penniesTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.penniesTextBox.Name = "penniesTextBox";
            this.penniesTextBox.Size = new System.Drawing.Size(132, 22);
            this.penniesTextBox.TabIndex = 8;
            this.penniesTextBox.Text = "0";
            // 
            // winnerPictureBox
            // 
            this.winnerPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("winnerPictureBox.Image")));
            this.winnerPictureBox.InitialImage = null;
            this.winnerPictureBox.Location = new System.Drawing.Point(736, 23);
            this.winnerPictureBox.Margin = new System.Windows.Forms.Padding(4);
            this.winnerPictureBox.Name = "winnerPictureBox";
            this.winnerPictureBox.Size = new System.Drawing.Size(287, 320);
            this.winnerPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.winnerPictureBox.TabIndex = 9;
            this.winnerPictureBox.TabStop = false;
            this.winnerPictureBox.Visible = false;
            // 
            // loserPictureBox
            // 
            this.loserPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("loserPictureBox.Image")));
            this.loserPictureBox.Location = new System.Drawing.Point(666, 13);
            this.loserPictureBox.Margin = new System.Windows.Forms.Padding(4);
            this.loserPictureBox.Name = "loserPictureBox";
            this.loserPictureBox.Size = new System.Drawing.Size(357, 357);
            this.loserPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.loserPictureBox.TabIndex = 10;
            this.loserPictureBox.TabStop = false;
            this.loserPictureBox.Visible = false;
            // 
            // guessAmountLabel
            // 
            this.guessAmountLabel.AutoSize = true;
            this.guessAmountLabel.Location = new System.Drawing.Point(16, 384);
            this.guessAmountLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.guessAmountLabel.Name = "guessAmountLabel";
            this.guessAmountLabel.Size = new System.Drawing.Size(197, 17);
            this.guessAmountLabel.TabIndex = 11;
            this.guessAmountLabel.Text = "Guess Amount (more or less):";
            // 
            // guessAmountAnswerLabel
            // 
            this.guessAmountAnswerLabel.AutoSize = true;
            this.guessAmountAnswerLabel.Location = new System.Drawing.Point(216, 384);
            this.guessAmountAnswerLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.guessAmountAnswerLabel.Name = "guessAmountAnswerLabel";
            this.guessAmountAnswerLabel.Size = new System.Drawing.Size(0, 17);
            this.guessAmountAnswerLabel.TabIndex = 12;
            // 
            // confirmButton
            // 
            this.confirmButton.Location = new System.Drawing.Point(20, 444);
            this.confirmButton.Margin = new System.Windows.Forms.Padding(4);
            this.confirmButton.Name = "confirmButton";
            this.confirmButton.Size = new System.Drawing.Size(160, 28);
            this.confirmButton.TabIndex = 13;
            this.confirmButton.Text = "Confirm Guess";
            this.confirmButton.UseVisualStyleBackColor = true;
            this.confirmButton.Click += new System.EventHandler(this.confirmButton_Click);
            // 
            // playAgainButton
            // 
            this.playAgainButton.Location = new System.Drawing.Point(244, 444);
            this.playAgainButton.Name = "playAgainButton";
            this.playAgainButton.Size = new System.Drawing.Size(115, 28);
            this.playAgainButton.TabIndex = 14;
            this.playAgainButton.Text = "Play Again ";
            this.playAgainButton.UseVisualStyleBackColor = true;
            this.playAgainButton.Click += new System.EventHandler(this.playAgainButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.playAgainButton);
            this.Controls.Add(this.confirmButton);
            this.Controls.Add(this.guessAmountAnswerLabel);
            this.Controls.Add(this.guessAmountLabel);
            this.Controls.Add(this.loserPictureBox);
            this.Controls.Add(this.winnerPictureBox);
            this.Controls.Add(this.penniesTextBox);
            this.Controls.Add(this.nickelTextBox);
            this.Controls.Add(this.dimesTextBox);
            this.Controls.Add(this.quarterTextBox);
            this.Controls.Add(this.penniesLabel);
            this.Controls.Add(this.nickelsLabel);
            this.Controls.Add(this.dimesLabel);
            this.Controls.Add(this.quartersLabel);
            this.Controls.Add(this.gameTitleLabel);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.winnerPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loserPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label gameTitleLabel;
        private System.Windows.Forms.Label quartersLabel;
        private System.Windows.Forms.Label dimesLabel;
        private System.Windows.Forms.Label nickelsLabel;
        private System.Windows.Forms.Label penniesLabel;
        private System.Windows.Forms.TextBox quarterTextBox;
        private System.Windows.Forms.TextBox dimesTextBox;
        private System.Windows.Forms.TextBox nickelTextBox;
        private System.Windows.Forms.TextBox penniesTextBox;
        private System.Windows.Forms.PictureBox winnerPictureBox;
        private System.Windows.Forms.PictureBox loserPictureBox;
        private System.Windows.Forms.Label guessAmountLabel;
        private System.Windows.Forms.Label guessAmountAnswerLabel;
        private System.Windows.Forms.Button confirmButton;
        private System.Windows.Forms.Button playAgainButton;
    }
}

