﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FallingLibrary
{
    public class FallingCalculation
    {
        public static double DistanceFallen(double userGravity, double userTime)
        {
            double distance;
            distance = 0.5 * (userGravity * Math.Pow(userTime, 2));
            return distance;
        }
    }
}
