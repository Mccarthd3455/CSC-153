﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FallingLibrary;

/**
* 3/20/2023
* CSC 153
* David McCarthy
* Ask user for time fallen then calculates the distance fallen based off of the time and force of gravity
*/
namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
            
        }

        private void timeCalculateButton_Click(object sender, EventArgs e)
        {
            double userTime; // user input variable for time (used in calculations)
            const double userGravity = 9.8; //Constant Variable for gravity (used in calculations
            
            double distanceFallen; //Variable for distance fallen
            userTime = double.Parse(timeAnswerTextBox.Text); //Converts user input to a double
            distanceFallen = FallingCalculation.DistanceFallen(userGravity , userTime); //calls calculation method
            
            distanceFallenLabel.Text = ("Distance Fallen " + distanceFallen.ToString() + " meters."); //Writes output out on the label

        }
    }
}
