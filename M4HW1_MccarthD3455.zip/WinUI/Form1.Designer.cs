﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.timeQuestionLabel = new System.Windows.Forms.Label();
            this.timeAnswerTextBox = new System.Windows.Forms.TextBox();
            this.timeCalculateButton = new System.Windows.Forms.Button();
            this.distanceFallenLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // timeQuestionLabel
            // 
            this.timeQuestionLabel.AutoSize = true;
            this.timeQuestionLabel.Location = new System.Drawing.Point(33, 25);
            this.timeQuestionLabel.Name = "timeQuestionLabel";
            this.timeQuestionLabel.Size = new System.Drawing.Size(159, 13);
            this.timeQuestionLabel.TabIndex = 0;
            this.timeQuestionLabel.Text = "Enter in time the item has fallen: ";
            // 
            // timeAnswerTextBox
            // 
            this.timeAnswerTextBox.Location = new System.Drawing.Point(199, 25);
            this.timeAnswerTextBox.Name = "timeAnswerTextBox";
            this.timeAnswerTextBox.Size = new System.Drawing.Size(100, 20);
            this.timeAnswerTextBox.TabIndex = 1;
            // 
            // timeCalculateButton
            // 
            this.timeCalculateButton.Location = new System.Drawing.Point(51, 202);
            this.timeCalculateButton.Name = "timeCalculateButton";
            this.timeCalculateButton.Size = new System.Drawing.Size(75, 23);
            this.timeCalculateButton.TabIndex = 2;
            this.timeCalculateButton.Text = "Calculate";
            this.timeCalculateButton.UseVisualStyleBackColor = true;
            this.timeCalculateButton.Click += new System.EventHandler(this.timeCalculateButton_Click);
            // 
            // distanceFallenLabel
            // 
            this.distanceFallenLabel.AutoSize = true;
            this.distanceFallenLabel.Location = new System.Drawing.Point(36, 65);
            this.distanceFallenLabel.Name = "distanceFallenLabel";
            this.distanceFallenLabel.Size = new System.Drawing.Size(83, 13);
            this.distanceFallenLabel.TabIndex = 3;
            this.distanceFallenLabel.Text = "Distance Fallen:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.distanceFallenLabel);
            this.Controls.Add(this.timeCalculateButton);
            this.Controls.Add(this.timeAnswerTextBox);
            this.Controls.Add(this.timeQuestionLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label timeQuestionLabel;
        private System.Windows.Forms.TextBox timeAnswerTextBox;
        private System.Windows.Forms.Button timeCalculateButton;
        private System.Windows.Forms.Label distanceFallenLabel;
    }
}

