﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.userInputQuestionLabel = new System.Windows.Forms.Label();
            this.userInputAnswerTextBox = new System.Windows.Forms.TextBox();
            this.remainingSecondsLabel = new System.Windows.Forms.Label();
            this.minutesLabel = new System.Windows.Forms.Label();
            this.hoursLabel = new System.Windows.Forms.Label();
            this.daysLabel = new System.Windows.Forms.Label();
            this.timeCalculationButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // userInputQuestionLabel
            // 
            this.userInputQuestionLabel.AutoSize = true;
            this.userInputQuestionLabel.Location = new System.Drawing.Point(26, 26);
            this.userInputQuestionLabel.Name = "userInputQuestionLabel";
            this.userInputQuestionLabel.Size = new System.Drawing.Size(187, 13);
            this.userInputQuestionLabel.TabIndex = 0;
            this.userInputQuestionLabel.Text = "Enter in an amount of time in seconds:";
            // 
            // userInputAnswerTextBox
            // 
            this.userInputAnswerTextBox.Location = new System.Drawing.Point(220, 26);
            this.userInputAnswerTextBox.Name = "userInputAnswerTextBox";
            this.userInputAnswerTextBox.Size = new System.Drawing.Size(100, 20);
            this.userInputAnswerTextBox.TabIndex = 1;
            // 
            // remainingSecondsLabel
            // 
            this.remainingSecondsLabel.AutoSize = true;
            this.remainingSecondsLabel.Location = new System.Drawing.Point(26, 52);
            this.remainingSecondsLabel.Name = "remainingSecondsLabel";
            this.remainingSecondsLabel.Size = new System.Drawing.Size(61, 13);
            this.remainingSecondsLabel.TabIndex = 2;
            this.remainingSecondsLabel.Text = "Second(s): ";
            // 
            // minutesLabel
            // 
            this.minutesLabel.AutoSize = true;
            this.minutesLabel.Location = new System.Drawing.Point(26, 83);
            this.minutesLabel.Name = "minutesLabel";
            this.minutesLabel.Size = new System.Drawing.Size(53, 13);
            this.minutesLabel.TabIndex = 3;
            this.minutesLabel.Text = "Minute(s):";
            // 
            // hoursLabel
            // 
            this.hoursLabel.AutoSize = true;
            this.hoursLabel.Location = new System.Drawing.Point(26, 113);
            this.hoursLabel.Name = "hoursLabel";
            this.hoursLabel.Size = new System.Drawing.Size(44, 13);
            this.hoursLabel.TabIndex = 4;
            this.hoursLabel.Text = "Hour(s):";
            // 
            // daysLabel
            // 
            this.daysLabel.AutoSize = true;
            this.daysLabel.Location = new System.Drawing.Point(26, 144);
            this.daysLabel.Name = "daysLabel";
            this.daysLabel.Size = new System.Drawing.Size(40, 13);
            this.daysLabel.TabIndex = 5;
            this.daysLabel.Text = "Day(s):";
            // 
            // timeCalculationButton
            // 
            this.timeCalculationButton.Location = new System.Drawing.Point(29, 220);
            this.timeCalculationButton.Name = "timeCalculationButton";
            this.timeCalculationButton.Size = new System.Drawing.Size(157, 23);
            this.timeCalculationButton.TabIndex = 6;
            this.timeCalculationButton.Text = "Calculate Time";
            this.timeCalculationButton.UseVisualStyleBackColor = true;
            this.timeCalculationButton.Click += new System.EventHandler(this.timeCalculationButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.timeCalculationButton);
            this.Controls.Add(this.daysLabel);
            this.Controls.Add(this.hoursLabel);
            this.Controls.Add(this.minutesLabel);
            this.Controls.Add(this.remainingSecondsLabel);
            this.Controls.Add(this.userInputAnswerTextBox);
            this.Controls.Add(this.userInputQuestionLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label userInputQuestionLabel;
        private System.Windows.Forms.TextBox userInputAnswerTextBox;
        private System.Windows.Forms.Label remainingSecondsLabel;
        private System.Windows.Forms.Label minutesLabel;
        private System.Windows.Forms.Label hoursLabel;
        private System.Windows.Forms.Label daysLabel;
        private System.Windows.Forms.Button timeCalculationButton;
    }
}

