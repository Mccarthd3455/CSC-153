﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 2/20/2023
* CSC 153
* David McCarthy
* This program takes the user input and gets the total days, hours, minutes and remaining seconds from it and displays it.
*/
namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void timeCalculationButton_Click(object sender, EventArgs e)
        {
            const int daySeconds = 86400; //Constant for how many seconds are in a day
            const int hourSeconds = 3600; //Constant for how many seconds are in a hour
            const int minuteSeconds = 60; //Constant for how many seconds are in a minute
            int remainder;
            int remainingSeconds;
            int totalMinutes;
            int totalHours;
            int totalDays;
            int userInput;
            
            userInput = int.Parse(userInputAnswerTextBox.Text);
            if(userInput < minuteSeconds && userInput > 0) 
            {
                remainingSecondsLabel.Text = ("Second(s): " + userInput); // Displays users Input as answers because user did not put 60 or greater in the input
            }
            else if(userInput >= minuteSeconds && userInput < hourSeconds)
            {
                totalMinutes = userInput / minuteSeconds; //Calculations for amount of minutes from the users input
                remainingSeconds = userInput % minuteSeconds; 
                minutesLabel.Text = ("Minute(s): " + totalMinutes);
                remainingSecondsLabel.Text = ("Second(s): " + remainingSeconds);
            }
            else if (userInput >= hourSeconds && userInput < daySeconds)
            {
                totalHours = userInput / hourSeconds;
                remainder = userInput % hourSeconds;
                totalMinutes = remainder / minuteSeconds;
                remainingSeconds = totalMinutes % minuteSeconds;
                hoursLabel.Text = ("Hour(s): " + totalHours);
                minutesLabel.Text = ("Minute(s): " + totalMinutes);
                remainingSecondsLabel.Text = ("Second(s): " + remainingSeconds);
            }
            else if (userInput >= daySeconds)
            {
                totalDays = userInput / daySeconds;
                remainder = userInput % daySeconds;
                totalHours = remainder / hourSeconds;
                remainder = remainder % hourSeconds;
                totalMinutes = remainder / minuteSeconds;
                remainingSeconds = totalMinutes % minuteSeconds;

                daysLabel.Text = ("Day(s): " + totalDays);
                hoursLabel.Text = ("Hour(s): " + totalHours);
                minutesLabel.Text = ("Minute(s): " + totalMinutes);
                remainingSecondsLabel.Text = ("Second(s): " + remainingSeconds);
            }
            else
            {
                remainingSecondsLabel.Text = ("Second(s): Invalid Time");
            }
        }
    }
}
